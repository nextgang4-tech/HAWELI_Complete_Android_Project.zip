package com.haweli

import android.app.Application
import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.haweli.database.DatabasePaths
import com.haweli.firebase.FirebaseClient

/**
 * Application class initializing Firebase (with automatic fallback options if google-services.json
 * was not bundled during mobile GitHub build) and enabling offline disk persistence on startup.
 */
class HaweliApplication : Application() {

    companion object {
        lateinit var appContext: Context
            private set

        fun ensureFirebaseInitialized(context: Context) {
            try {
                if (FirebaseApp.getApps(context).isNotEmpty()) return
                val defaultApp = FirebaseApp.initializeApp(context)
                if (defaultApp == null) {
                    val options = FirebaseOptions.Builder()
                        .setApplicationId("1:100000000000:android:haweli123rtdb")
                        .setProjectId("haweli123-default-rtdb")
                        .setDatabaseUrl(DatabasePaths.DATABASE_URL)
                        .setApiKey("AIzaSyHaweliAccountingRtdbFallbackKey000")
                        .build()
                    FirebaseApp.initializeApp(context, options)
                }
            } catch (_: Exception) {
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext
        ensureFirebaseInitialized(applicationContext)
        try {
            FirebaseClient.database
        } catch (_: Exception) {
        }
    }
}
