package com.haweli.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.HaweliViewModel
import com.haweli.admin.AdminOnlySection
import com.haweli.calculations.AccountingCalculator
import com.haweli.models.AccessRole
import com.haweli.models.VehicleEntry
import com.haweli.ui.components.*
import com.haweli.ui.theme.*
import com.haweli.utils.DateAndFormatUtils

/**
 * 9. OBAD TO HYDERABAD GAADI MANAGEMENT SCREEN (ओबाद से हैदराबाद गाड़ी)
 * Features:
 * - Daily vehicle entries (7 fields: तारीख, गाड़ी नंबर, बड़ा माल का वजन, वील माल का वजन, कुल वजन, ओबाद का विवरण, हैदराबाद का विवरण)
 * - ओबाद बनाम हैदराबाद Comparison Dashboard
 * - MONTHLY REPORT (मासिक रिपोर्ट: कुल गाड़ियां, बड़ा माल कितना कटा, वील माल कितना कटा, ओबाद कुल वजन, हैदराबाद कुल वजन, अंतर)
 */
@Composable
fun ObadHyderabadGaadiScreen(
    viewModel: HaweliViewModel,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val isConnected by viewModel.isConnected.collectAsState()
    val pendingWrites by viewModel.pendingWriteCount.collectAsState()
    val accessRole by viewModel.accessRole.collectAsState()
    val allVehicles by viewModel.vehicleEntries.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var dateFilter by remember { mutableStateOf("") }
    var monthFilter by remember { mutableStateOf(DateAndFormatUtils.currentMonthYear()) }
    var yearFilter by remember { mutableStateOf("") }
    var newestFirst by remember { mutableStateOf(true) }

    var showVehicleDialog by remember { mutableStateOf(false) }
    var editingVehicle by remember { mutableStateOf<VehicleEntry?>(null) }
    var vehicleToDelete by remember { mutableStateOf<VehicleEntry?>(null) }

    val activeMonth = if (monthFilter.isNotBlank()) monthFilter.trim() else DateAndFormatUtils.currentMonthYear()
    val overallSummary = remember(allVehicles) {
        AccountingCalculator.calculateVehicleComparisonSummary(allVehicles)
    }
    val monthlyVehicles = remember(allVehicles, activeMonth) {
        allVehicles.filter { it.monthYear == activeMonth }
    }
    val monthlySummary = remember(monthlyVehicles) {
        AccountingCalculator.calculateVehicleComparisonSummary(monthlyVehicles)
    }

    val filteredVehiclesRaw = allVehicles.filter { v ->
        (searchQuery.isBlank() ||
            v.vehicleNumber.contains(searchQuery.trim(), ignoreCase = true) ||
            v.date.contains(searchQuery.trim()) ||
            v.obadDetails.contains(searchQuery.trim(), ignoreCase = true) ||
            v.hyderabadDetails.contains(searchQuery.trim(), ignoreCase = true)) &&
            (dateFilter.isBlank() || v.date == dateFilter.trim()) &&
            (monthFilter.isBlank() || v.monthYear == monthFilter.trim()) &&
            (yearFilter.isBlank() || v.date.endsWith(yearFilter.trim()))
    }
    val filteredVehicles = if (newestFirst) {
        filteredVehiclesRaw.sortedByDescending { it.dateEpoch }
    } else {
        filteredVehiclesRaw.sortedBy { it.dateEpoch }
    }

    Scaffold(
        topBar = {
            HaweliTopBar(
                title = "ओबाद से हैदराबाद गाड़ी प्रबंधन",
                isConnected = isConnected,
                pendingWrites = pendingWrites,
                accessRole = accessRole,
                onBackClick = onBack,
                onSettingsClick = onOpenSettings
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            // 1. COMPARISON DASHBOARD: ओबाद बनाम हैदराबाद
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                    border = BorderStroke(1.5.dp, HaweliNavyBlue),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ओबाद बनाम हैदराबाद (तुलना डैशबोर्ड)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = HaweliNavyBlue
                            )
                            Text(
                                text = "कुल गाड़ियां: ${overallSummary.totalVehiclesCount}",
                                fontWeight = FontWeight.Bold,
                                color = HaweliDarkGreen
                            )
                        }
                        Divider(color = HaweliCardBorder)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ओबाद में कुल बड़ा माल: ${overallSummary.totalObadBadaWeight}", fontSize = 13.5.sp)
                            Text("हैदराबाद में कुल बड़ा माल: ${overallSummary.totalHyderabadBadaWeight}", fontSize = 13.5.sp)
                        }
                        Text(
                            text = "बड़ा माल का अंतर: ${overallSummary.totalBadaDiff} कि.ग्रा.",
                            fontWeight = FontWeight.Bold,
                            color = HaweliPaymentRed,
                            fontSize = 14.sp
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ओबाद में कुल वील माल: ${overallSummary.totalObadVeelWeight}", fontSize = 13.5.sp)
                            Text("हैदराबाद में कुल वील माल: ${overallSummary.totalHyderabadVeelWeight}", fontSize = 13.5.sp)
                        }
                        Text(
                            text = "वील माल का अंतर: ${overallSummary.totalVeelDiff} कि.ग्रा.",
                            fontWeight = FontWeight.Bold,
                            color = HaweliPaymentRed,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // 2. MONTHLY REPORT CARD (मासिक गाड़ी रिपोर्ट)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = HaweliPositiveGreenLight),
                    border = BorderStroke(1.5.dp, HaweliDarkGreen),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "मासिक गाड़ी रिपोर्ट ($activeMonth)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = HaweliDarkGreen
                        )
                        Text("• इस महीने कुल कितनी गाड़ियां आईं: ${monthlySummary.totalVehiclesCount}")
                        Text(
                            text = "• इस महीने बड़ा माल कितना कटा (अंतर): ${monthlySummary.totalBadaDiff} कि.ग्रा.",
                            color = HaweliPaymentRed,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "• इस महीने वील माल कितना कटा (अंतर): ${monthlySummary.totalVeelDiff} कि.ग्रा.",
                            color = HaweliPaymentRed,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("• ओबाद का कुल वजन: ${monthlySummary.totalObadWeight}", fontWeight = FontWeight.SemiBold)
                            Text("• हैदराबाद का कुल वजन: ${monthlySummary.totalHyderabadWeight}", fontWeight = FontWeight.SemiBold)
                        }
                        Text(
                            text = "• दोनों के बीच कुल अंतर: ${monthlySummary.totalOverallDiff} कि.ग्रा.",
                            fontWeight = FontWeight.Bold,
                            color = HaweliPaymentRed
                        )
                    }
                }
            }

            item {
                ModuleSearchAndFilterBar(
                    searchQuery = searchQuery,
                    onSearchChange = { searchQuery = it },
                    searchPlaceholder = "गाड़ी नंबर या तारीख खोजें...",
                    dateFilter = dateFilter,
                    onDateFilterChange = { dateFilter = it },
                    monthFilter = monthFilter,
                    onMonthFilterChange = { monthFilter = it },
                    yearFilter = yearFilter,
                    onYearFilterChange = { yearFilter = it },
                    newestFirst = newestFirst,
                    onSortToggle = { newestFirst = !newestFirst },
                    onClearFilters = {
                        searchQuery = ""
                        dateFilter = ""
                        monthFilter = ""
                        yearFilter = ""
                    }
                )
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "गाड़ी रिकॉर्ड सूची (${filteredVehicles.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = HaweliNavyBlue
                    )
                    AdminOnlySection(accessRole) {
                        Button(
                            onClick = {
                                editingVehicle = null
                                showVehicleDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("गाड़ी एंट्री जोड़ें")
                        }
                    }
                }
            }

            items(filteredVehicles, key = { it.id }) { vehicle ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, HaweliCardBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "1. तारीख: ${vehicle.date}  |  2. गाड़ी नं: ${vehicle.vehicleNumber}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = HaweliNavyBlue
                            )
                            AdminOnlySection(accessRole) {
                                Row {
                                    IconButton(onClick = {
                                        editingVehicle = vehicle
                                        showVehicleDialog = true
                                    }) {
                                        Icon(Icons.Default.Edit, contentDescription = "बदलें", tint = HaweliNavyBlue)
                                    }
                                    IconButton(onClick = { vehicleToDelete = vehicle }) {
                                        Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = HaweliPaymentRed)
                                    }
                                }
                            }
                        }

                        Divider(color = HaweliCardBorder)

                        Text(
                            text = "ओबाद वजन → 3. बड़ा माल: ${vehicle.obadBadaWeight} | 4. वील माल: ${vehicle.obadVeelWeight} | 5. कुल: ${vehicle.obadTotalWeight}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = HaweliDarkGreen
                        )
                        Text(
                            text = "हैदराबाद वजन → बड़ा माल: ${vehicle.hyderabadBadaWeight} | वील माल: ${vehicle.hyderabadVeelWeight} | कुल: ${vehicle.hyderabadTotalWeight}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = HaweliNavyBlue
                        )
                        Text(
                            text = "वजन अंतर → बड़ा माल अंतर: ${vehicle.badaWeightDiff} | वील माल अंतर: ${vehicle.veelWeightDiff} | कुल अंतर: ${vehicle.totalWeightDiff}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = HaweliPaymentRed
                        )
                        if (vehicle.obadDetails.isNotBlank()) {
                            Text("6. ओबाद का विवरण: ${vehicle.obadDetails}", fontSize = 13.5.sp)
                        }
                        if (vehicle.hyderabadDetails.isNotBlank()) {
                            Text("7. हैदराबाद का विवरण: ${vehicle.hyderabadDetails}", fontSize = 13.5.sp)
                        }
                    }
                }
            }
        }
    }

    if (showVehicleDialog) {
        var date by remember { mutableStateOf(editingVehicle?.date ?: DateAndFormatUtils.todayFormatted()) }
        var vehicleNumber by remember { mutableStateOf(editingVehicle?.vehicleNumber ?: "") }
        var obadBada by remember { mutableStateOf(editingVehicle?.obadBadaWeight ?: "0.00") }
        var obadVeel by remember { mutableStateOf(editingVehicle?.obadVeelWeight ?: "0.00") }
        var hydBada by remember { mutableStateOf(editingVehicle?.hyderabadBadaWeight ?: "0.00") }
        var hydVeel by remember { mutableStateOf(editingVehicle?.hyderabadVeelWeight ?: "0.00") }
        var obadDetails by remember { mutableStateOf(editingVehicle?.obadDetails ?: "") }
        var hydDetails by remember { mutableStateOf(editingVehicle?.hyderabadDetails ?: "") }

        val obadTotal = AccountingCalculator.add(obadBada, obadVeel)
        val hydTotal = AccountingCalculator.add(hydBada, hydVeel)
        val badaDiff = AccountingCalculator.subtract(obadBada, hydBada)
        val veelDiff = AccountingCalculator.subtract(obadVeel, hydVeel)

        AlertDialog(
            onDismissRequest = { showVehicleDialog = false },
            title = { Text(if (editingVehicle == null) "नई गाड़ी एंट्री (ओबाद से हैदराबाद)" else "गाड़ी एंट्री संपादित करें") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("1. तारीख (DD-MM-YYYY)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = vehicleNumber,
                        onValueChange = { vehicleNumber = it },
                        label = { Text("2. गाड़ी नंबर (जैसे MH28AB1234)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("ओबाद का वजन विवरण:", fontWeight = FontWeight.Bold, color = HaweliDarkGreen)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HindiDecimalField(
                            value = obadBada,
                            onValueChange = { obadBada = it },
                            label = "3. ओबाद बड़ा माल वजन",
                            modifier = Modifier.weight(1f)
                        )
                        HindiDecimalField(
                            value = obadVeel,
                            onValueChange = { obadVeel = it },
                            label = "4. ओबाद वील माल वजन",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Text("5. ओबाद कुल वजन: ${obadTotal.toPlainString()} कि.ग्रा.", fontWeight = FontWeight.SemiBold)

                    Text("हैदराबाद का वजन विवरण:", fontWeight = FontWeight.Bold, color = HaweliNavyBlue)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HindiDecimalField(
                            value = hydBada,
                            onValueChange = { hydBada = it },
                            label = "हैदराबाद बड़ा माल वजन",
                            modifier = Modifier.weight(1f)
                        )
                        HindiDecimalField(
                            value = hydVeel,
                            onValueChange = { hydVeel = it },
                            label = "हैदराबाद वील माल वजन",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Text("हैदराबाद कुल वजन: ${hydTotal.toPlainString()} कि.ग्रा.", fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "बड़ा माल अंतर: ${badaDiff.toPlainString()} | वील माल अंतर: ${veelDiff.toPlainString()}",
                        fontWeight = FontWeight.Bold,
                        color = HaweliPaymentRed
                    )
                    OutlinedTextField(
                        value = obadDetails,
                        onValueChange = { obadDetails = it },
                        label = { Text("6. ओबाद का विवरण") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = hydDetails,
                        onValueChange = { hydDetails = it },
                        label = { Text("7. हैदराबाद का विवरण") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (vehicleNumber.isNotBlank()) {
                            viewModel.repository.saveVehicleEntry(
                                VehicleEntry(
                                    id = editingVehicle?.id ?: "",
                                    date = date,
                                    vehicleNumber = vehicleNumber,
                                    obadBadaWeight = obadBada,
                                    obadVeelWeight = obadVeel,
                                    hyderabadBadaWeight = hydBada,
                                    hyderabadVeelWeight = hydVeel,
                                    obadDetails = obadDetails,
                                    hyderabadDetails = hydDetails,
                                    createdAt = editingVehicle?.createdAt ?: System.currentTimeMillis()
                                )
                            )
                            showVehicleDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showVehicleDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    vehicleToDelete?.let { v ->
        ConfirmDeleteDialog(
            message = "क्या आप गाड़ी नंबर '${v.vehicleNumber}' (${v.date}) का रिकॉर्ड हटाना चाहते हैं?",
            onConfirm = { viewModel.repository.deleteVehicleEntry(v.id) },
            onDismiss = { vehicleToDelete = null }
        )
    }
}
