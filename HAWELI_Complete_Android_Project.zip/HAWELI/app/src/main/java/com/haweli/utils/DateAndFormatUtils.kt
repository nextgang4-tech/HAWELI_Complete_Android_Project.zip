package com.haweli.utils

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Date formatting (DD-MM-YYYY) and Indian Rupee (₹) formatting utilities.
 */
object DateAndFormatUtils {

    private const val DATE_PATTERN = "dd-MM-yyyy"
    private const val DATE_TIME_PATTERN = "dd-MM-yyyy hh:mm a"

    fun todayFormatted(): String {
        val sdf = SimpleDateFormat(DATE_PATTERN, Locale.US)
        return sdf.format(Date())
    }

    fun currentMonthYear(): String {
        val cal = Calendar.getInstance()
        val month = cal.get(Calendar.MONTH) + 1
        val year = cal.get(Calendar.YEAR)
        return String.format(Locale.US, "%02d-%04d", month, year)
    }

    fun currentYear(): String {
        val cal = Calendar.getInstance()
        return cal.get(Calendar.YEAR).toString()
    }

    fun formatTimestamp(epochMillis: Long): String {
        val sdf = SimpleDateFormat(DATE_TIME_PATTERN, Locale("hi", "IN"))
        return sdf.format(Date(epochMillis))
    }

    /**
     * Normalizes user-entered or picker-selected dates into DD-MM-YYYY format.
     */
    fun normalizeDate(input: String): String {
        val trimmed = input.trim().replace("/", "-").replace(".", "-")
        if (trimmed.isEmpty()) return todayFormatted()
        val parts = trimmed.split("-")
        if (parts.size == 3) {
            return if (parts[0].length == 4) {
                // Convert YYYY-MM-DD to DD-MM-YYYY
                val y = parts[0].toIntOrNull() ?: 2026
                val m = parts[1].toIntOrNull()?.coerceIn(1, 12) ?: 1
                val d = parts[2].toIntOrNull()?.coerceIn(1, 31) ?: 1
                String.format(Locale.US, "%02d-%02d-%04d", d, m, y)
            } else {
                val d = parts[0].toIntOrNull()?.coerceIn(1, 31) ?: 1
                val m = parts[1].toIntOrNull()?.coerceIn(1, 12) ?: 1
                val y = parts[2].toIntOrNull() ?: 2026
                String.format(Locale.US, "%02d-%02d-%04d", d, m, y)
            }
        }
        return todayFormatted()
    }

    fun parseDateToEpoch(ddMmYyyy: String): Long {
        return try {
            val normalized = normalizeDate(ddMmYyyy)
            val sdf = SimpleDateFormat(DATE_PATTERN, Locale.US)
            sdf.isLenient = false
            sdf.parse(normalized)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }

    fun extractMonthYear(ddMmYyyy: String): String {
        val normalized = normalizeDate(ddMmYyyy)
        val parts = normalized.split("-")
        return if (parts.size == 3) {
            "${parts[1]}-${parts[2]}"
        } else {
            currentMonthYear()
        }
    }

    fun extractYear(ddMmYyyy: String): String {
        val normalized = normalizeDate(ddMmYyyy)
        val parts = normalized.split("-")
        return if (parts.size == 3) {
            parts[2]
        } else {
            currentYear()
        }
    }

    fun formatIndianCurrency(amountStr: String?): String {
        val bd = try {
            BigDecimal(amountStr?.trim()?.replace(",", "") ?: "0.00")
                .setScale(2, RoundingMode.HALF_UP)
        } catch (e: Exception) {
            BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
        }
        val isNegative = bd < BigDecimal.ZERO
        val absVal = bd.abs()
        val formatter = DecimalFormat("#,##,##0.00")
        val formatted = formatter.format(absVal)
        return if (isNegative) "-₹ $formatted" else "₹ $formatted"
    }

    fun formatWeight(weightStr: String?, unit: String = "कि.ग्रा."): String {
        val bd = try {
            BigDecimal(weightStr?.trim()?.replace(",", "") ?: "0.00")
                .setScale(2, RoundingMode.HALF_UP)
        } catch (e: Exception) {
            BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
        }
        return "${bd.toPlainString()} $unit"
    }

    fun hindiMonthName(monthYear: String): String {
        val parts = monthYear.split("-")
        if (parts.size != 2) return monthYear
        val monthName = when (parts[0]) {
            "01" -> "जनवरी"
            "02" -> "फरवरी"
            "03" -> "मार्च"
            "04" -> "अप्रैल"
            "05" -> "मई"
            "06" -> "जून"
            "07" -> "जुलाई"
            "08" -> "अगस्त"
            "09" -> "सितंबर"
            "10" -> "अक्टूबर"
            "11" -> "नवंबर"
            "12" -> "दिसंबर"
            else -> parts[0]
        }
        return "$monthName ${parts[1]}"
    }
}
