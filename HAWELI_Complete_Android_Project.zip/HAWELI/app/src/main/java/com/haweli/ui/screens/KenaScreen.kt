package com.haweli.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.HaweliViewModel
import com.haweli.admin.AdminOnlySection
import com.haweli.calculations.AccountingCalculator
import com.haweli.models.*
import com.haweli.ui.components.*
import com.haweli.ui.theme.*
import com.haweli.utils.DateAndFormatUtils
import java.math.BigDecimal

/**
 * 7. KENA / केना MANAGEMENT SCREEN
 * Features:
 * - Add/Edit/Delete party name
 * - Date-wise daily entries (9 fields)
 * - Monthly totals (कुल केना इस महीने, कुल रकम, प्राप्त भुगतान RED, बाकी आना / एडवांस)
 * - Party-wise accounting & Date-wise reports
 */
@Composable
fun KenaScreen(
    viewModel: HaweliViewModel,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val isConnected by viewModel.isConnected.collectAsState()
    val pendingWrites by viewModel.pendingWriteCount.collectAsState()
    val accessRole by viewModel.accessRole.collectAsState()
    val allParties by viewModel.parties.collectAsState()
    val allEntries by viewModel.kenaEntries.collectAsState()

    val kenaParties = remember(allParties) { allParties.filter { it.module == "KENA" } }
    var selectedParty by remember { mutableStateOf<PartyRecord?>(null) }
    val activeParty = remember(selectedParty, kenaParties) {
        selectedParty?.let { sel -> kenaParties.find { it.id == sel.id } ?: sel }
    }

    var searchQuery by remember { mutableStateOf("") }
    var dateFilter by remember { mutableStateOf("") }
    var monthFilter by remember { mutableStateOf(DateAndFormatUtils.currentMonthYear()) }
    var yearFilter by remember { mutableStateOf("") }
    var newestFirst by remember { mutableStateOf(true) }

    var showPartyDialog by remember { mutableStateOf(false) }
    var editingParty by remember { mutableStateOf<PartyRecord?>(null) }
    var partyToDelete by remember { mutableStateOf<PartyRecord?>(null) }

    var showEntryDialog by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<KenaEntry?>(null) }
    var entryToDelete by remember { mutableStateOf<KenaEntry?>(null) }

    val activeMonth = if (monthFilter.isNotBlank()) monthFilter.trim() else DateAndFormatUtils.currentMonthYear()
    val monthEntries = remember(allEntries, activeMonth) {
        allEntries.filter { it.monthYear == activeMonth }
    }
    val monthTotalKena = remember(monthEntries) {
        monthEntries.fold(BigDecimal.ZERO) { acc, e -> acc.add(AccountingCalculator.parseDecimal(e.totalKena)) }
    }
    val monthTotalAmount = remember(monthEntries) {
        monthEntries.fold(BigDecimal.ZERO) { acc, e -> acc.add(AccountingCalculator.parseDecimal(e.totalAmount)) }
    }
    val monthTotalReceived = remember(monthEntries) {
        monthEntries.fold(BigDecimal.ZERO) { acc, e -> acc.add(AccountingCalculator.parseDecimal(e.receivedPayment)) }
    }

    Scaffold(
        topBar = {
            HaweliTopBar(
                title = if (activeParty == null) "केना प्रबंधन (पार्टी व मासिक हिसाब)" else "केना हिसाब: ${activeParty.name}",
                isConnected = isConnected,
                pendingWrites = pendingWrites,
                accessRole = accessRole,
                onBackClick = { if (activeParty != null) selectedParty = null else onBack() },
                onSettingsClick = onOpenSettings
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Monthly Kena Summary Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                border = BorderStroke(1.5.dp, HaweliDarkGreen)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "मासिक केना सारांश ($activeMonth)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = HaweliNavyBlue
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            text = "कुल केना इस महीने: ${AccountingCalculator.formatDecimal(monthTotalKena)}",
                            fontWeight = FontWeight.Bold,
                            color = HaweliDarkGreen
                        )
                        Text(
                            text = "कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(monthTotalAmount.toPlainString())}",
                            fontWeight = FontWeight.Bold,
                            color = HaweliNavyBlue
                        )
                    }
                    Text(
                        text = "प्राप्त भुगतान (इस महीने): ${DateAndFormatUtils.formatIndianCurrency(monthTotalReceived.toPlainString())}",
                        fontWeight = FontWeight.Bold,
                        color = HaweliPaymentRed
                    )
                }
            }

            ModuleSearchAndFilterBar(
                searchQuery = searchQuery,
                onSearchChange = { searchQuery = it },
                searchPlaceholder = "पार्टी का नाम या तारीख खोजें...",
                dateFilter = dateFilter,
                onDateFilterChange = { dateFilter = it },
                monthFilter = monthFilter,
                onMonthFilterChange = { monthFilter = it },
                yearFilter = yearFilter,
                onYearFilterChange = { yearFilter = it },
                newestFirst = newestFirst,
                onSortToggle = { newestFirst = !newestFirst },
                onClearFilters = {
                    searchQuery = ""
                    dateFilter = ""
                    monthFilter = ""
                    yearFilter = ""
                }
            )

            if (activeParty == null) {
                val filteredParties = kenaParties.filter {
                    searchQuery.isBlank() || it.name.contains(searchQuery.trim(), ignoreCase = true)
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "केना पार्टियां (${filteredParties.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = HaweliNavyBlue
                    )
                    AdminOnlySection(accessRole) {
                        Button(
                            onClick = {
                                editingParty = null
                                showPartyDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("पार्टी जोड़ें")
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredParties, key = { it.id }) { party ->
                        PartySummaryCard(
                            party = party,
                            accessRole = accessRole,
                            onClick = { selectedParty = party },
                            onEdit = {
                                editingParty = party
                                showPartyDialog = true
                            },
                            onDelete = { partyToDelete = party }
                        )
                    }
                }
            } else {
                val entriesRaw = allEntries.filter { e ->
                    e.partyId == activeParty.id &&
                        (searchQuery.isBlank() || e.date.contains(searchQuery.trim())) &&
                        (dateFilter.isBlank() || e.date == dateFilter.trim()) &&
                        (monthFilter.isBlank() || e.monthYear == monthFilter.trim()) &&
                        (yearFilter.isBlank() || e.date.endsWith(yearFilter.trim()))
                }
                val entries = if (newestFirst) {
                    entriesRaw.sortedByDescending { it.dateEpoch }
                } else {
                    entriesRaw.sortedBy { it.dateEpoch }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BalanceBadge(
                        balanceAmount = activeParty.currentBalance,
                        balanceStatusLabel = activeParty.balanceStatus
                    )
                    AdminOnlySection(accessRole) {
                        Button(
                            onClick = {
                                editingEntry = null
                                showEntryDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("केना एंट्री जोड़ें")
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(entries, key = { it.id }) { entry ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, HaweliCardBorder),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "1. पार्टी: ${entry.partyName} | 2. तारीख: ${entry.date}",
                                        fontWeight = FontWeight.Bold,
                                        color = HaweliNavyBlue
                                    )
                                    AdminOnlySection(accessRole) {
                                        Row {
                                            IconButton(onClick = {
                                                editingEntry = entry
                                                showEntryDialog = true
                                            }) {
                                                Icon(Icons.Default.Edit, contentDescription = "बदलें", tint = HaweliNavyBlue)
                                            }
                                            IconButton(onClick = { entryToDelete = entry }) {
                                                Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = HaweliPaymentRed)
                                            }
                                        }
                                    }
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("3. कुल केना: ${entry.totalKena}", fontWeight = FontWeight.SemiBold)
                                    Text("4. रेट: ₹${entry.rate}", fontWeight = FontWeight.SemiBold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(
                                        text = "5. कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(entry.totalAmount)}",
                                        fontWeight = FontWeight.Bold,
                                        color = HaweliDarkGreen
                                    )
                                    Text(
                                        text = "6. पिछला बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(entry.previousBalance)}",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                RedPaymentRow(
                                    label = "7-8. प्राप्त भुगतान",
                                    paymentAmount = entry.receivedPayment,
                                    paymentDate = entry.paymentDate
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("9. बाकी बैलेंस:", fontWeight = FontWeight.Bold)
                                    BalanceBadge(
                                        balanceAmount = entry.remainingBalance,
                                        balanceStatusLabel = entry.balanceStatus
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPartyDialog) {
        var partyName by remember(editingParty) { mutableStateOf(editingParty?.name ?: "") }
        var openingBal by remember(editingParty) { mutableStateOf(editingParty?.openingBalance ?: "0.00") }
        AlertDialog(
            onDismissRequest = { showPartyDialog = false },
            title = { Text(if (editingParty == null) "केना पार्टी जोड़ें" else "पार्टी का नाम बदलें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = partyName,
                        onValueChange = { partyName = it },
                        label = { Text("पार्टी का नाम") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = openingBal,
                        onValueChange = { openingBal = it },
                        label = "प्रारंभिक (पिछला) बैलेंस (₹)",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (partyName.isNotBlank()) {
                            viewModel.repository.saveParty(
                                module = "KENA",
                                name = partyName,
                                openingBalance = openingBal,
                                existingId = editingParty?.id
                            )
                            showPartyDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showPartyDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    partyToDelete?.let { party ->
        ConfirmDeleteDialog(
            message = "क्या आप केना पार्टी '${party.name}' को हटाना चाहते हैं?",
            onConfirm = { viewModel.repository.deleteParty(party) },
            onDismiss = { partyToDelete = null }
        )
    }

    if (showEntryDialog && activeParty != null) {
        var date by remember { mutableStateOf(editingEntry?.date ?: DateAndFormatUtils.todayFormatted()) }
        var totalKena by remember { mutableStateOf(editingEntry?.totalKena ?: "0.00") }
        var rate by remember { mutableStateOf(editingEntry?.rate ?: "0.00") }
        var receivedPayment by remember { mutableStateOf(editingEntry?.receivedPayment ?: "0.00") }
        var paymentDate by remember { mutableStateOf(editingEntry?.paymentDate ?: DateAndFormatUtils.todayFormatted()) }

        val totalAmt = AccountingCalculator.multiply(totalKena, rate)

        AlertDialog(
            onDismissRequest = { showEntryDialog = false },
            title = { Text("केना एंट्री (${activeParty.name})") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("2. तारीख (DD-MM-YYYY)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = totalKena,
                        onValueChange = { totalKena = it },
                        label = "3. कुल केना",
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = rate,
                        onValueChange = { rate = it },
                        label = "4. रेट (₹)",
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "5. कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(totalAmt.toPlainString())}",
                        fontWeight = FontWeight.Bold,
                        color = HaweliDarkGreen
                    )
                    HindiDecimalField(
                        value = receivedPayment,
                        onValueChange = { receivedPayment = it },
                        label = "7. प्राप्त भुगतान (₹ - लाल रंग)",
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = paymentDate,
                        onValueChange = { paymentDate = it },
                        label = { Text("8. भुगतान की तारीख (DD-MM-YYYY)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.repository.saveKenaEntry(
                            activeParty,
                            KenaEntry(
                                id = editingEntry?.id ?: "",
                                date = date,
                                totalKena = totalKena,
                                rate = rate,
                                receivedPayment = receivedPayment,
                                paymentDate = paymentDate,
                                createdAt = editingEntry?.createdAt ?: System.currentTimeMillis()
                            )
                        )
                        showEntryDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showEntryDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    entryToDelete?.let { entry ->
        if (activeParty != null) {
            ConfirmDeleteDialog(
                message = "क्या आप तारीख ${entry.date} की केना एंट्री हटाना चाहते हैं?",
                onConfirm = { viewModel.repository.deleteKenaEntry(activeParty, entry.id) },
                onDismiss = { entryToDelete = null }
            )
        }
    }
}
