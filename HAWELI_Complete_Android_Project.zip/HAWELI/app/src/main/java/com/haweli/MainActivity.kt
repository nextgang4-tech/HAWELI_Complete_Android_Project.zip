package com.haweli

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.haweli.admin.ForcePasswordChangeDialog
import com.haweli.models.AccessRole
import com.haweli.navigation.HaweliNavGraph
import com.haweli.ui.theme.HaweliTheme

/**
 * MainActivity hosting the Jetpack Compose UI, enforcing mandatory initial password change
 * when logged in as Admin for the first time, and opening directly in Viewer Mode for normal users.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HaweliTheme {
                val haweliViewModel: HaweliViewModel = viewModel()
                val navController = rememberNavController()

                val accessRole by haweliViewModel.accessRole.collectAsState()
                val mustChangePassword by haweliViewModel.mustChangePassword.collectAsState()
                val authError by haweliViewModel.authError.collectAsState()
                val authBusy by haweliViewModel.authBusy.collectAsState()

                Surface(modifier = Modifier.fillMaxSize()) {
                    HaweliNavGraph(
                        navController = navController,
                        viewModel = haweliViewModel
                    )

                    if (accessRole == AccessRole.ADMIN && mustChangePassword) {
                        ForcePasswordChangeDialog(
                            errorMessage = authError,
                            isBusy = authBusy,
                            onSubmitNewPassword = { currentPass, newPass, confirmPass ->
                                haweliViewModel.changeAdminPassword(currentPass, newPass, confirmPass)
                            }
                        )
                    }
                }
            }
        }
    }
}
