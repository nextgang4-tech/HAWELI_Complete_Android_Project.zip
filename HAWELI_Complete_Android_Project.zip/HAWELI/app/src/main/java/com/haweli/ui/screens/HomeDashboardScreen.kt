package com.haweli.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.HaweliViewModel
import com.haweli.admin.AdminLoginDialog
import com.haweli.navigation.HaweliRoutes
import com.haweli.ui.components.BalanceBadge
import com.haweli.ui.components.HaweliTopBar
import com.haweli.ui.theme.*
import com.haweli.utils.DateAndFormatUtils
import com.haweli.viewer.ViewerModeBanner

data class MainMenuItem(
    val number: Int,
    val titleHindi: String,
    val subtitleHindi: String,
    val route: String,
    val icon: ImageVector
)

/**
 * 2. HOME DASHBOARD & 3. MAIN MENU & 15. GLOBAL SEARCH
 * Displays:
 * - CARD 1: कुल आना (Total Outstanding Receivables across all modules)
 * - CARD 2: कुल देना (Total Outstanding Payables across all modules)
 * - Global Search Bar (वैश्विक खोज: पार्टी का नाम, शहर, या गाड़ी नंबर)
 * - 8 Main Menu Sections in Hindi
 */
@Composable
fun HomeDashboardScreen(
    viewModel: HaweliViewModel,
    onNavigate: (String) -> Unit
) {
    val isConnected by viewModel.isConnected.collectAsState()
    val pendingWrites by viewModel.pendingWriteCount.collectAsState()
    val accessRole by viewModel.accessRole.collectAsState()
    val dashboardTotals by viewModel.dashboardTotals.collectAsState()
    val parties by viewModel.parties.collectAsState()
    val cities by viewModel.cities.collectAsState()
    val vehicles by viewModel.vehicleEntries.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val authBusy by viewModel.authBusy.collectAsState()

    var globalSearchQuery by remember { mutableStateOf("") }
    var showAdminLoginModal by remember { mutableStateOf(false) }

    val menuItems = remember {
        listOf(
            MainMenuItem(
                1,
                "4PC पार्टी",
                "शहर → पार्टी का नाम → बड़ा व वील माल हिसाब",
                HaweliRoutes.FOUR_PC_PARTY,
                Icons.Default.Groups
            ),
            MainMenuItem(
                2,
                "हैदराबाद कंपनी",
                "पार्टी का नाम → बड़ा व वील माल बिक्री एवं प्राप्त भुगतान",
                HaweliRoutes.HYDERABAD_COMPANY,
                Icons.Default.Business
            ),
            MainMenuItem(
                3,
                "चमड़ा",
                "चमड़ा आवक, चमड़ा बिक्री एवं बचा हुआ स्टॉक",
                HaweliRoutes.CHAMDA,
                Icons.Default.Inventory2
            ),
            MainMenuItem(
                4,
                "केना",
                "तारीख-वार केना एंट्री, मासिक जोड़ एवं पार्टी हिसाब",
                HaweliRoutes.KENA,
                Icons.Default.Category
            ),
            MainMenuItem(
                5,
                "पोटली",
                "तारीख-वार पोटली एंट्री, मासिक कुल पोटली एवं बाकी बैलेंस",
                HaweliRoutes.POTLI,
                Icons.Default.Workspaces
            ),
            MainMenuItem(
                6,
                "ओबाद से हैदराबाद गाड़ी",
                "गाड़ी वजन रिकॉर्ड एवं ओबाद बनाम हैदराबाद तुलना डैशबोर्ड",
                HaweliRoutes.OBAD_HYDERABAD_GAADI,
                Icons.Default.LocalShipping
            ),
            MainMenuItem(
                7,
                "रिपोर्ट",
                "सभी विभागों की हिंदी पीडीएफ रिपोर्ट, व्हाट्सऐप शेयर व प्रिंट",
                HaweliRoutes.REPORTS,
                Icons.Default.PictureAsPdf
            ),
            MainMenuItem(
                8,
                "सेटिंग",
                "एडमिन लॉगिन, पासवर्ड, सिंक स्थिति, बैकअप/रीस्टोर व ऐप शेयर",
                HaweliRoutes.SETTINGS,
                Icons.Default.Settings
            )
        )
    }

    Scaffold(
        topBar = {
            HaweliTopBar(
                title = "HAWELI - हवेली बिज़नेस हिसाब",
                isConnected = isConnected,
                pendingWrites = pendingWrites,
                accessRole = accessRole,
                onSettingsClick = { onNavigate(HaweliRoutes.SETTINGS) }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            item {
                ViewerModeBanner(
                    accessRole = accessRole,
                    onAdminLoginClick = {
                        viewModel.clearAuthError()
                        showAdminLoginModal = true
                    }
                )
            }

            // TOP TWO LARGE ACCOUNTING CARDS: कुल आना & कुल देना
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // CARD 1: कुल आना (Green positive receivable card)
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = HaweliPositiveGreenLight),
                        border = BorderStroke(2.dp, HaweliPositiveGreen),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "कुल आना",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = HaweliDarkGreen
                            )
                            Text(
                                text = DateAndFormatUtils.formatIndianCurrency(dashboardTotals.kulAana),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = HaweliPositiveGreen
                            )
                            Text(
                                text = "हैदराबाद, चमड़ा बिक्री, केना व पोटली से कुल लेनदारी",
                                fontSize = 12.sp,
                                color = HaweliDarkGreen
                            )
                        }
                    }

                    // CARD 2: कुल देना (Red/Navy payable card)
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = HaweliPaymentRedLight),
                        border = BorderStroke(2.dp, HaweliPaymentRed),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "कुल देना",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = HaweliPaymentRed
                            )
                            Text(
                                text = DateAndFormatUtils.formatIndianCurrency(dashboardTotals.kulDena),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = HaweliPaymentRed
                            )
                            Text(
                                text = "4PC पार्टी व अन्य विभागों की कुल देनदारी",
                                fontSize = 12.sp,
                                color = HaweliPaymentRed
                            )
                        }
                    }
                }
            }

            // GLOBAL SEARCH BAR ON HOME SCREEN
            item {
                OutlinedTextField(
                    value = globalSearchQuery,
                    onValueChange = { globalSearchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    label = { Text("वैश्विक खोज: पार्टी का नाम, शहर या गाड़ी नंबर खोजें...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "खोजें") },
                    trailingIcon = {
                        if (globalSearchQuery.isNotEmpty()) {
                            IconButton(onClick = { globalSearchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "साफ़ करें")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // GLOBAL SEARCH RESULTS WHEN ACTIVE
            if (globalSearchQuery.isNotBlank()) {
                val q = globalSearchQuery.trim()
                val matchingParties = parties.filter {
                    it.name.contains(q, ignoreCase = true) ||
                        it.cityName.contains(q, ignoreCase = true)
                }
                val matchingCities = cities.filter { it.name.contains(q, ignoreCase = true) }
                val matchingVehicles = vehicles.filter {
                    it.vehicleNumber.contains(q, ignoreCase = true) ||
                        it.date.contains(q, ignoreCase = true)
                }

                item {
                    Text(
                        text = "खोज परिणाम (${matchingParties.size + matchingCities.size + matchingVehicles.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = HaweliNavyBlue,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }

                items(matchingParties, key = { "party_${it.id}" }) { party ->
                    val targetRoute = when (party.module) {
                        "FOUR_PC" -> HaweliRoutes.FOUR_PC_PARTY
                        "HYDERABAD" -> HaweliRoutes.HYDERABAD_COMPANY
                        "CHAMDA_SALES" -> HaweliRoutes.CHAMDA
                        "KENA" -> HaweliRoutes.KENA
                        "POTLI" -> HaweliRoutes.POTLI
                        else -> HaweliRoutes.HOME_DASHBOARD
                    }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                            .clickable { onNavigate(targetRoute) },
                        colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                        border = BorderStroke(1.dp, HaweliCardBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = party.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = HaweliNavyBlue
                                )
                                Text(
                                    text = "विभाग: ${moduleHindiLabel(party.module)} ${if (party.cityName.isNotBlank()) "| शहर: ${party.cityName}" else ""}",
                                    fontSize = 13.sp,
                                    color = Color.DarkGray
                                )
                            }
                            BalanceBadge(
                                balanceAmount = party.currentBalance,
                                balanceStatusLabel = party.balanceStatus
                            )
                        }
                    }
                }

                items(matchingVehicles, key = { "veh_${it.id}" }) { veh ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                            .clickable { onNavigate(HaweliRoutes.OBAD_HYDERABAD_GAADI) },
                        colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                        border = BorderStroke(1.dp, HaweliCardBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "गाड़ी नंबर: ${veh.vehicleNumber}",
                                    fontWeight = FontWeight.Bold,
                                    color = HaweliNavyBlue
                                )
                                Text(
                                    text = "तारीख: ${veh.date} | ओबाद कुल वजन: ${veh.obadTotalWeight} | हैदराबाद कुल वजन: ${veh.hyderabadTotalWeight}",
                                    fontSize = 13.sp
                                )
                            }
                            Text(
                                text = "अंतर: ${veh.totalWeightDiff}",
                                fontWeight = FontWeight.Bold,
                                color = HaweliPaymentRed
                            )
                        }
                    }
                }
            }

            // MAIN MENU HEADER
            item {
                Text(
                    text = "मुख्य मेनू (सभी विभाग)",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = HaweliNavyBlue,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }

            // 8 MAIN MENU CARDS
            items(menuItems, key = { it.number }) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .clickable { onNavigate(item.route) },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.5.dp, HaweliCardBorder),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            color = if (item.number % 2 == 1) HaweliDarkGreen else HaweliNavyBlue,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.titleHindi,
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${item.number}. ${item.titleHindi}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = HaweliNavyBlue
                            )
                            Text(
                                text = item.subtitleHindi,
                                fontSize = 13.5.sp,
                                color = Color(0xFF455A64)
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "खोलें",
                            tint = HaweliDarkGreen
                        )
                    }
                }
            }
        }
    }

    if (showAdminLoginModal) {
        AdminLoginDialog(
            errorMessage = authError,
            isBusy = authBusy,
            onLoginSubmit = { user, pass ->
                viewModel.loginAdmin(user, pass) {
                    showAdminLoginModal = false
                }
            },
            onDismiss = { showAdminLoginModal = false }
        )
    }
}

fun moduleHindiLabel(module: String): String = when (module) {
    "FOUR_PC" -> "4PC पार्टी"
    "HYDERABAD" -> "हैदराबाद कंपनी"
    "CHAMDA_SALES" -> "चमड़ा बिक्री"
    "KENA" -> "केना"
    "POTLI" -> "पोटली"
    else -> module
}
