package com.haweli.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * HAWELI Color Palette & Hindi Typography:
 * - White background (#FFFFFF / #F7FAF8)
 * - Dark Green primary (#0D5C3A) and Navy Blue secondary (#102A56)
 * - Payment & Negative Balance Red (#C62828)
 * - Positive Balance Green (#1B7A43)
 * - Large, high-contrast Hindi fonts for comfortable reading on all Android phones
 */
val HaweliDarkGreen = Color(0xFF0D5C3A)
val HaweliNavyBlue = Color(0xFF102A56)
val HaweliPaymentRed = Color(0xFFC62828)
val HaweliPaymentRedLight = Color(0xFFFFEBEE)
val HaweliPositiveGreen = Color(0xFF1B7A43)
val HaweliPositiveGreenLight = Color(0xFFE8F5E9)
val HaweliWhite = Color(0xFFFFFFFF)
val HaweliSurfaceLight = Color(0xFFF6F9F7)
val HaweliCardBorder = Color(0xFFD5E2DC)

private val HaweliLightColorScheme = lightColorScheme(
    primary = HaweliDarkGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7EFE3),
    onPrimaryContainer = HaweliDarkGreen,
    secondary = HaweliNavyBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCE4F5),
    onSecondaryContainer = HaweliNavyBlue,
    error = HaweliPaymentRed,
    onError = Color.White,
    background = HaweliWhite,
    onBackground = Color(0xFF121815),
    surface = HaweliWhite,
    onSurface = Color(0xFF121815),
    surfaceVariant = HaweliSurfaceLight,
    onSurfaceVariant = Color(0xFF36453E)
)

val HaweliHindiTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 34.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 30.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 19.sp,
        lineHeight = 26.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp,
        lineHeight = 24.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 23.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 21.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        lineHeight = 20.sp
    )
)

@Composable
fun HaweliTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = HaweliLightColorScheme,
        typography = HaweliHindiTypography,
        content = content
    )
}
