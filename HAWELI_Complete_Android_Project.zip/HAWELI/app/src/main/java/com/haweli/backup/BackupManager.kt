package com.haweli.backup

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.gson.GsonBuilder
import com.google.gson.JsonParser
import com.haweli.models.HaweliBackupPayload
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader

/**
 * Handles complete JSON Backup export, structural validation, and safe Restore for HAWELI.
 */
object BackupManager {

    private val gson = GsonBuilder().setPrettyPrinting().create()

    fun createBackupJsonFile(context: Context, payload: HaweliBackupPayload): File {
        val backupDir = File(context.cacheDir, "backups")
        if (!backupDir.exists()) backupDir.mkdirs()

        val fileName = "HAWELI_Backup_${System.currentTimeMillis()}.json"
        val file = File(backupDir, fileName)
        val jsonContent = gson.toJson(payload)
        file.writeText(jsonContent, Charsets.UTF_8)
        return file
    }

    fun saveBackupToDownloads(context: Context, backupFile: File): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, backupFile.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HAWELI_Backups")
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(backupFile).use { input -> input.copyTo(out) }
                    }
                    Toast.makeText(
                        context,
                        "बैकअप फ़ाइल Downloads/HAWELI_Backups/${backupFile.name} में सुरक्षित की गई।",
                        Toast.LENGTH_LONG
                    ).show()
                    "Downloads/HAWELI_Backups/${backupFile.name}"
                } else {
                    backupFile.absolutePath
                }
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    "HAWELI_Backups"
                )
                if (!dir.exists()) dir.mkdirs()
                val dest = File(dir, backupFile.name)
                backupFile.copyTo(dest, overwrite = true)
                Toast.makeText(
                    context,
                    "बैकअप सहेजा गया: ${dest.absolutePath}",
                    Toast.LENGTH_LONG
                ).show()
                dest.absolutePath
            }
        } catch (e: Exception) {
            backupFile.absolutePath
        }
    }

    fun shareBackupFile(context: Context, backupFile: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            backupFile
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "HAWELI JSON बैकअप फ़ाइल")
            putExtra(
                Intent.EXTRA_TEXT,
                "HAWELI बिज़नेस अकाउंटिंग का संपूर्ण डेटा बैकअप (${backupFile.name})"
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "बैकअप फ़ाइल साझा करें"))
    }

    /**
     * Reads and strictly validates a JSON backup from a content Uri or raw JSON text
     * before allowing the Admin to confirm restoration.
     */
    fun parseAndValidateBackupFromUri(context: Context, uri: Uri): Result<HaweliBackupPayload> {
        return try {
            val content = context.contentResolver.openInputStream(uri)?.use { stream ->
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
            } ?: return Result.failure(Exception("बैकअप फ़ाइल पढ़ने में असमर्थ।"))

            parseAndValidateBackupJson(content)
        } catch (e: Exception) {
            Result.failure(Exception("अमान्य बैकअप फ़ाइल: ${e.localizedMessage ?: ""}"))
        }
    }

    fun parseAndValidateBackupJson(rawJson: String): Result<HaweliBackupPayload> {
        return try {
            val rootElement = JsonParser.parseString(rawJson)
            if (!rootElement.isJsonObject) {
                return Result.failure(Exception("बैकअप फ़ाइल वैध JSON ऑब्जेक्ट नहीं है।"))
            }
            val obj = rootElement.asJsonObject
            val appName = obj.get("applicationName")?.asString ?: ""
            if (appName != "HAWELI") {
                return Result.failure(Exception("यह फ़ाइल HAWELI एप्लीकेशन का मान्य बैकअप नहीं है।"))
            }
            if (!obj.has("parties") || !obj.has("fourPcEntries") || !obj.has("hyderabadEntries")) {
                return Result.failure(Exception("बैकअप संरचना अधूरी है (पार्टी या हिसाब डेटा अनुपस्थित)।"))
            }

            val payload = gson.fromJson(rawJson, HaweliBackupPayload::class.java)
                ?: return Result.failure(Exception("बैकअप डेटा पार्स करने में विफल।"))

            Result.success(payload)
        } catch (e: Exception) {
            Result.failure(Exception("बैकअप सत्यापन विफल: ${e.localizedMessage ?: "गलत JSON प्रारूप"}"))
        }
    }
}
