package com.haweli.utils

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/**
 * Handles sharing the installed HAWELI APK file safely via Android FileProvider,
 * or sharing the verified APK download link when the base APK file is not directly readable.
 */
object AppShareUtils {

    fun shareApplicationApkOrLink(context: Context, fallbackDownloadUrl: String) {
        try {
            val sourcePath = context.applicationInfo.sourceDir
            val sourceApkFile = if (!sourcePath.isNullOrBlank()) File(sourcePath) else null

            if (sourceApkFile != null && sourceApkFile.exists() && sourceApkFile.canRead()) {
                val apkCacheDir = File(context.cacheDir, "apk")
                if (!apkCacheDir.exists()) apkCacheDir.mkdirs()

                val targetApk = File(apkCacheDir, "HAWELI-Accounting.apk")
                sourceApkFile.copyTo(targetApk, overwrite = true)

                val apkUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    targetApk
                )

                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/vnd.android.package-archive"
                    putExtra(Intent.EXTRA_STREAM, apkUri)
                    putExtra(
                        Intent.EXTRA_SUBJECT,
                        "HAWELI - हवेली बिज़नेस हिसाब एप्लीकेशन (APK)"
                    )
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "HAWELI (हवेली) बिज़नेस अकाउंटिंग ऐप इंस्टॉल करने के लिए संलग्न APK फ़ाइल खोलें। इंस्टॉल होने पर यह अपने आप व्यूअर मोड में खुलेगा।"
                    )
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                context.startActivity(
                    Intent.createChooser(shareIntent, "HAWELI APK साझा करें")
                )
            } else {
                shareDownloadLinkOnly(context, fallbackDownloadUrl)
            }
        } catch (e: Exception) {
            shareDownloadLinkOnly(context, fallbackDownloadUrl)
        }
    }

    private fun shareDownloadLinkOnly(context: Context, downloadUrl: String) {
        Toast.makeText(
            context,
            "स्थानीय APK फ़ाइल सीधे उपलब्ध नहीं है, आधिकारिक डाउनलोड लिंक साझा किया जा रहा है।",
            Toast.LENGTH_LONG
        ).show()

        val linkIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "HAWELI - हवेली हिसाब ऐप डाउनलोड लिंक")
            putExtra(
                Intent.EXTRA_TEXT,
                "HAWELI बिज़नेस अकाउंटिंग ऐप यहाँ से डाउनलोड करें:\n$downloadUrl"
            )
        }
        context.startActivity(Intent.createChooser(linkIntent, "डाउनलोड लिंक साझा करें"))
    }
}
