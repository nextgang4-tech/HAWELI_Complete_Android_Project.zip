package com.haweli.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.HaweliViewModel
import com.haweli.admin.AdminOnlySection
import com.haweli.calculations.AccountingCalculator
import com.haweli.models.*
import com.haweli.ui.components.*
import com.haweli.ui.theme.*
import com.haweli.utils.DateAndFormatUtils

/**
 * 4. 4PC PARTY MANAGEMENT SCREEN
 * Hierarchy:
 * 4PC पार्टी → शहर (City) → पार्टी का नाम (Party Name) → हिसाब (Party Ledger)
 * Also includes "सभी पार्टी खाते देखें" (View all party accounts across cities).
 */
@Composable
fun FourPcPartyScreen(
    viewModel: HaweliViewModel,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val isConnected by viewModel.isConnected.collectAsState()
    val pendingWrites by viewModel.pendingWriteCount.collectAsState()
    val accessRole by viewModel.accessRole.collectAsState()
    val cities by viewModel.cities.collectAsState()
    val allParties by viewModel.parties.collectAsState()
    val allEntries by viewModel.fourPcEntries.collectAsState()

    val fourPcParties = remember(allParties) {
        allParties.filter { it.module == "FOUR_PC" }
    }

    var selectedCity by remember { mutableStateOf<CityRecord?>(null) }
    var selectedParty by remember { mutableStateOf<PartyRecord?>(null) }
    var showAllPartiesMode by remember { mutableStateOf(false) }

    // Search & filter state
    var searchQuery by remember { mutableStateOf("") }
    var dateFilter by remember { mutableStateOf("") }
    var monthFilter by remember { mutableStateOf("") }
    var yearFilter by remember { mutableStateOf("") }
    var newestFirst by remember { mutableStateOf(true) }

    // Dialog states (Admin only)
    var showCityDialog by remember { mutableStateOf(false) }
    var editingCity by remember { mutableStateOf<CityRecord?>(null) }
    var cityToDelete by remember { mutableStateOf<CityRecord?>(null) }

    var showPartyDialog by remember { mutableStateOf(false) }
    var editingParty by remember { mutableStateOf<PartyRecord?>(null) }
    var partyToDelete by remember { mutableStateOf<PartyRecord?>(null) }

    var showEntryDialog by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<FourPcEntry?>(null) }
    var entryToDelete by remember { mutableStateOf<FourPcEntry?>(null) }

    // Keep selectedParty synced with latest balance updates
    val activeParty = remember(selectedParty, fourPcParties) {
        selectedParty?.let { sel -> fourPcParties.find { it.id == sel.id } ?: sel }
    }

    val topTitle = when {
        activeParty != null -> "4PC हिसाब: ${activeParty.name} (${activeParty.cityName})"
        selectedCity != null -> "4PC शहर: ${selectedCity!!.name}"
        showAllPartiesMode -> "4PC पार्टी: सभी पार्टी खाते"
        else -> "4PC पार्टी प्रबंधन (शहर सूची)"
    }

    Scaffold(
        topBar = {
            HaweliTopBar(
                title = topTitle,
                isConnected = isConnected,
                pendingWrites = pendingWrites,
                accessRole = accessRole,
                onBackClick = {
                    when {
                        activeParty != null -> selectedParty = null
                        selectedCity != null -> selectedCity = null
                        showAllPartiesMode -> showAllPartiesMode = false
                        else -> onBack()
                    }
                },
                onSettingsClick = onOpenSettings
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            ModuleSearchAndFilterBar(
                searchQuery = searchQuery,
                onSearchChange = { searchQuery = it },
                searchPlaceholder = "शहर, पार्टी का नाम या तारीख खोजें...",
                dateFilter = dateFilter,
                onDateFilterChange = { dateFilter = it },
                monthFilter = monthFilter,
                onMonthFilterChange = { monthFilter = it },
                yearFilter = yearFilter,
                onYearFilterChange = { yearFilter = it },
                newestFirst = newestFirst,
                onSortToggle = { newestFirst = !newestFirst },
                onClearFilters = {
                    searchQuery = ""
                    dateFilter = ""
                    monthFilter = ""
                    yearFilter = ""
                }
            )

            // LEVEL 1: CITY LIST OR ALL PARTIES TOGGLE
            if (selectedCity == null && activeParty == null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = !showAllPartiesMode,
                        onClick = { showAllPartiesMode = false },
                        label = { Text("शहर के अनुसार (${cities.size})") }
                    )
                    FilterChip(
                        selected = showAllPartiesMode,
                        onClick = { showAllPartiesMode = true },
                        label = { Text("सभी पार्टी खाते देखें (${fourPcParties.size})") }
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    AdminOnlySection(accessRole) {
                        Button(
                            onClick = {
                                editingCity = null
                                showCityDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("शहर जोड़ें")
                        }
                    }
                }

                if (!showAllPartiesMode) {
                    val filteredCities = cities.filter {
                        searchQuery.isBlank() || it.name.contains(searchQuery.trim(), ignoreCase = true)
                    }
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (filteredCities.isEmpty()) {
                            item {
                                Text(
                                    text = "कोई शहर दर्ज नहीं है। एडमिन मोड में 'शहर जोड़ें' बटन दबाकर नया शहर जोड़ें।",
                                    modifier = Modifier.padding(16.dp),
                                    color = Color.Gray
                                )
                            }
                        }
                        items(filteredCities, key = { it.id }) { city ->
                            val cityParties = fourPcParties.filter { it.cityId == city.id }
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedCity = city },
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, HaweliCardBorder)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "शहर: ${city.name}",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = HaweliNavyBlue
                                        )
                                        Text(
                                            text = "कुल पार्टियां: ${cityParties.size}",
                                            fontSize = 14.sp,
                                            color = Color.DarkGray
                                        )
                                    }
                                    AdminOnlySection(accessRole) {
                                        Row {
                                            IconButton(onClick = {
                                                editingCity = city
                                                showCityDialog = true
                                            }) {
                                                Icon(Icons.Default.Edit, contentDescription = "शहर बदलें", tint = HaweliNavyBlue)
                                            }
                                            IconButton(onClick = { cityToDelete = city }) {
                                                Icon(Icons.Default.Delete, contentDescription = "शहर हटाएं", tint = HaweliPaymentRed)
                                            }
                                        }
                                    }
                                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = HaweliDarkGreen)
                                }
                            }
                        }
                    }
                } else {
                    // View All Party Accounts across all cities
                    val filteredAllParties = fourPcParties.filter {
                        searchQuery.isBlank() ||
                            it.name.contains(searchQuery.trim(), ignoreCase = true) ||
                            it.cityName.contains(searchQuery.trim(), ignoreCase = true)
                    }
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredAllParties, key = { it.id }) { party ->
                            PartySummaryCard(
                                party = party,
                                accessRole = accessRole,
                                onClick = { selectedParty = party },
                                onEdit = {
                                    editingParty = party
                                    showPartyDialog = true
                                },
                                onDelete = { partyToDelete = party }
                            )
                        }
                    }
                }
            }

            // LEVEL 2: PARTIES INSIDE SELECTED CITY
            if (selectedCity != null && activeParty == null) {
                val city = selectedCity!!
                val cityParties = fourPcParties.filter {
                    it.cityId == city.id &&
                        (searchQuery.isBlank() || it.name.contains(searchQuery.trim(), ignoreCase = true))
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${city.name} की पार्टियां (${cityParties.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = HaweliNavyBlue
                    )
                    AdminOnlySection(accessRole) {
                        Button(
                            onClick = {
                                editingParty = null
                                showPartyDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("पार्टी जोड़ें")
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (cityParties.isEmpty()) {
                        item {
                            Text(
                                text = "इस शहर में कोई पार्टी दर्ज नहीं है।",
                                modifier = Modifier.padding(16.dp),
                                color = Color.Gray
                            )
                        }
                    }
                    items(cityParties, key = { it.id }) { party ->
                        PartySummaryCard(
                            party = party,
                            accessRole = accessRole,
                            onClick = { selectedParty = party },
                            onEdit = {
                                editingParty = party
                                showPartyDialog = true
                            },
                            onDelete = { partyToDelete = party }
                        )
                    }
                }
            }

            // LEVEL 3: PARTY LEDGER (हिसाब)
            if (activeParty != null) {
                val partyEntriesRaw = allEntries.filter { entry ->
                    entry.partyId == activeParty.id &&
                        (searchQuery.isBlank() || entry.date.contains(searchQuery.trim()) || entry.notes.contains(searchQuery.trim(), true)) &&
                        (dateFilter.isBlank() || entry.date == dateFilter.trim()) &&
                        (monthFilter.isBlank() || entry.monthYear == monthFilter.trim()) &&
                        (yearFilter.isBlank() || entry.date.endsWith(yearFilter.trim()))
                }
                val partyEntries = if (newestFirst) {
                    partyEntriesRaw.sortedWith(compareByDescending<FourPcEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                } else {
                    partyEntriesRaw.sortedWith(compareBy<FourPcEntry> { it.dateEpoch }.thenBy { it.createdAt })
                }

                // Party Header Summary Banner
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                    border = BorderStroke(1.5.dp, HaweliDarkGreen)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "पार्टी: ${activeParty.name} (शहर: ${activeParty.cityName})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = HaweliNavyBlue
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            BalanceBadge(
                                balanceAmount = activeParty.currentBalance,
                                balanceStatusLabel = activeParty.balanceStatus
                            )
                        }
                        AdminOnlySection(accessRole) {
                            Button(
                                onClick = {
                                    editingEntry = null
                                    showEntryDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("नई एंट्री")
                            }
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (partyEntries.isEmpty()) {
                        item {
                            Text(
                                text = "इस पार्टी के लिए अभी कोई हिसाब एंट्री नहीं है।",
                                modifier = Modifier.padding(16.dp),
                                color = Color.Gray
                            )
                        }
                    }
                    items(partyEntries, key = { it.id }) { entry ->
                        FourPcEntryCard(
                            entry = entry,
                            accessRole = accessRole,
                            onEdit = {
                                editingEntry = entry
                                showEntryDialog = true
                            },
                            onDelete = { entryToDelete = entry }
                        )
                    }
                }
            }
        }
    }

    // DIALOGS
    if (showCityDialog) {
        var cityName by remember(editingCity) { mutableStateOf(editingCity?.name ?: "") }
        AlertDialog(
            onDismissRequest = { showCityDialog = false },
            title = { Text(if (editingCity == null) "नया शहर जोड़ें" else "शहर का नाम बदलें") },
            text = {
                OutlinedTextField(
                    value = cityName,
                    onValueChange = { cityName = it },
                    label = { Text("शहर का नाम") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (cityName.isNotBlank()) {
                            viewModel.repository.saveCity(cityName, editingCity?.id)
                            showCityDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showCityDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    cityToDelete?.let { city ->
        ConfirmDeleteDialog(
            message = "क्या आप निश्चित रूप से शहर '${city.name}' और उससे जुड़े सभी खातों को हटाना चाहते हैं?",
            onConfirm = { viewModel.repository.deleteCity(city.id) },
            onDismiss = { cityToDelete = null }
        )
    }

    if (showPartyDialog) {
        val targetCity = selectedCity ?: cities.find { it.id == editingParty?.cityId }
        var partyName by remember(editingParty) { mutableStateOf(editingParty?.name ?: "") }
        var openingBal by remember(editingParty) { mutableStateOf(editingParty?.openingBalance ?: "0.00") }

        AlertDialog(
            onDismissRequest = { showPartyDialog = false },
            title = { Text(if (editingParty == null) "नई 4PC पार्टी जोड़ें" else "पार्टी विवरण बदलें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = partyName,
                        onValueChange = { partyName = it },
                        label = { Text("पार्टी का नाम") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = openingBal,
                        onValueChange = { openingBal = it },
                        label = "प्रारंभिक (पिछला) बैलेंस (₹)",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (partyName.isNotBlank() && targetCity != null) {
                            viewModel.repository.saveParty(
                                module = "FOUR_PC",
                                name = partyName,
                                cityId = targetCity.id,
                                cityName = targetCity.name,
                                openingBalance = openingBal,
                                existingId = editingParty?.id
                            )
                            showPartyDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showPartyDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    partyToDelete?.let { party ->
        ConfirmDeleteDialog(
            message = "क्या आप निश्चित रूप से पार्टी '${party.name}' और उसका पूरा हिसाब हटाना चाहते हैं?",
            onConfirm = { viewModel.repository.deleteParty(party) },
            onDismiss = { partyToDelete = null }
        )
    }

    if (showEntryDialog && activeParty != null) {
        FourPcEntryFormDialog(
            party = activeParty,
            initialEntry = editingEntry,
            onDismiss = { showEntryDialog = false },
            onSave = { draft ->
                viewModel.repository.saveFourPcEntry(activeParty, draft)
                showEntryDialog = false
            }
        )
    }

    entryToDelete?.let { entry ->
        if (activeParty != null) {
            ConfirmDeleteDialog(
                message = "क्या आप तारीख ${entry.date} की हिसाब एंट्री को हटाना चाहते हैं? शेष सभी बैलेंस स्वतः अपडेट हो जाएंगे।",
                onConfirm = { viewModel.repository.deleteFourPcEntry(activeParty, entry.id) },
                onDismiss = { entryToDelete = null }
            )
        }
    }
}

@Composable
fun PartySummaryCard(
    party: PartyRecord,
    accessRole: AccessRole,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, HaweliCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = party.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = HaweliNavyBlue
                )
                if (party.cityName.isNotBlank()) {
                    Text(
                        text = "शहर: ${party.cityName}",
                        fontSize = 13.sp,
                        color = Color.DarkGray
                    )
                }
                BalanceBadge(
                    balanceAmount = party.currentBalance,
                    balanceStatusLabel = party.balanceStatus
                )
            }
            AdminOnlySection(accessRole) {
                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "बदलें", tint = HaweliNavyBlue)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = HaweliPaymentRed)
                    }
                }
            }
        }
    }
}

@Composable
private fun FourPcEntryCard(
    entry: FourPcEntry,
    accessRole: AccessRole,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, HaweliCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "1. तारीख: ${entry.date}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = HaweliNavyBlue
                )
                AdminOnlySection(accessRole) {
                    Row {
                        IconButton(onClick = onEdit) {
                            Icon(Icons.Default.Edit, contentDescription = "एंट्री बदलें", tint = HaweliNavyBlue)
                        }
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Default.Delete, contentDescription = "एंट्री हटाएं", tint = HaweliPaymentRed)
                        }
                    }
                }
            }

            Divider(color = HaweliCardBorder)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("2. कुल बड़ा माल: ${entry.totalBadaMaalCount}", fontSize = 14.sp)
                Text("3. बड़ा माल का वजन: ${entry.badaMaalWeight} (रेट: ₹${entry.badaMaalRate})", fontSize = 14.sp)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("4. कुल वील माल: ${entry.totalVeelMaalCount}", fontSize = 14.sp)
                Text("5. वील माल का वजन: ${entry.veelMaalWeight} (रेट: ₹${entry.veelMaalRate})", fontSize = 14.sp)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "6. बड़ा माल की रकम: ${DateAndFormatUtils.formatIndianCurrency(entry.badaMaalAmount)}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                Text(
                    text = "7. वील माल की रकम: ${DateAndFormatUtils.formatIndianCurrency(entry.veelMaalAmount)}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "8. दोनों की कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(entry.totalCombinedAmount)}",
                    fontWeight = FontWeight.Bold,
                    color = HaweliDarkGreen,
                    fontSize = 15.sp
                )
                Text(
                    text = "9. पिछला बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(entry.previousBalance)}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }

            // 10 & 11: Payment Date and Payment Amount in RED colour
            RedPaymentRow(
                label = "10-11. भुगतान की रकम",
                paymentAmount = entry.paymentAmount,
                paymentDate = entry.paymentDate
            )

            // 12: Remaining Balance & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "12. बाकी बैलेंस:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                BalanceBadge(
                    balanceAmount = entry.remainingBalance,
                    balanceStatusLabel = entry.balanceStatus
                )
            }
        }
    }
}

@Composable
private fun FourPcEntryFormDialog(
    party: PartyRecord,
    initialEntry: FourPcEntry?,
    onDismiss: () -> Unit,
    onSave: (FourPcEntry) -> Unit
) {
    var date by remember { mutableStateOf(initialEntry?.date ?: DateAndFormatUtils.todayFormatted()) }
    var badaCount by remember { mutableStateOf(initialEntry?.totalBadaMaalCount ?: "0") }
    var badaWeight by remember { mutableStateOf(initialEntry?.badaMaalWeight ?: "0.00") }
    var badaRate by remember { mutableStateOf(initialEntry?.badaMaalRate ?: "0.00") }
    var veelCount by remember { mutableStateOf(initialEntry?.totalVeelMaalCount ?: "0") }
    var veelWeight by remember { mutableStateOf(initialEntry?.veelMaalWeight ?: "0.00") }
    var veelRate by remember { mutableStateOf(initialEntry?.veelMaalRate ?: "0.00") }
    var paymentDate by remember { mutableStateOf(initialEntry?.paymentDate ?: DateAndFormatUtils.todayFormatted()) }
    var paymentAmount by remember { mutableStateOf(initialEntry?.paymentAmount ?: "0.00") }

    val badaAmt = AccountingCalculator.multiply(badaWeight, badaRate)
    val veelAmt = AccountingCalculator.multiply(veelWeight, veelRate)
    val combinedAmt = badaAmt.add(veelAmt)
    val prevBal = initialEntry?.previousBalance ?: party.currentBalance
    val closingBal = AccountingCalculator.calculateClosingBalance(
        previousBalance = prevBal,
        newCharges = combinedAmt.toPlainString(),
        payment = paymentAmount
    )
    val closingStatus = AccountingCalculator.resolvePayableStatus(closingBal)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialEntry == null) "4PC पार्टी नई एंट्री (${party.name})" else "4PC एंट्री संपादित करें",
                fontWeight = FontWeight.Bold,
                color = HaweliNavyBlue
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("1. तारीख (DD-MM-YYYY)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HindiDecimalField(
                        value = badaCount,
                        onValueChange = { badaCount = it },
                        label = "2. कुल बड़ा माल (नग)",
                        modifier = Modifier.weight(1f)
                    )
                    HindiDecimalField(
                        value = badaWeight,
                        onValueChange = { badaWeight = it },
                        label = "3. बड़ा माल का वजन",
                        modifier = Modifier.weight(1f)
                    )
                }
                HindiDecimalField(
                    value = badaRate,
                    onValueChange = { badaRate = it },
                    label = "बड़ा माल का रेट (₹)",
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "6. बड़ा माल की रकम: ${DateAndFormatUtils.formatIndianCurrency(badaAmt.toPlainString())}",
                    fontWeight = FontWeight.SemiBold,
                    color = HaweliDarkGreen
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HindiDecimalField(
                        value = veelCount,
                        onValueChange = { veelCount = it },
                        label = "4. कुल वील माल (नग)",
                        modifier = Modifier.weight(1f)
                    )
                    HindiDecimalField(
                        value = veelWeight,
                        onValueChange = { veelWeight = it },
                        label = "5. वील माल का वजन",
                        modifier = Modifier.weight(1f)
                    )
                }
                HindiDecimalField(
                    value = veelRate,
                    onValueChange = { veelRate = it },
                    label = "वील माल का रेट (₹)",
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "7. वील माल की रकम: ${DateAndFormatUtils.formatIndianCurrency(veelAmt.toPlainString())}",
                    fontWeight = FontWeight.SemiBold,
                    color = HaweliDarkGreen
                )

                Text(
                    text = "8. दोनों की कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(combinedAmt.toPlainString())}",
                    fontWeight = FontWeight.Bold,
                    color = HaweliNavyBlue
                )
                Text(
                    text = "9. पिछला बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(prevBal)}",
                    fontWeight = FontWeight.SemiBold
                )

                OutlinedTextField(
                    value = paymentDate,
                    onValueChange = { paymentDate = it },
                    label = { Text("10. भुगतान की तारीख (DD-MM-YYYY)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                HindiDecimalField(
                    value = paymentAmount,
                    onValueChange = { paymentAmount = it },
                    label = "11. भुगतान की रकम (₹ - लाल रंग में दिखेगी)",
                    modifier = Modifier.fillMaxWidth()
                )

                BalanceBadge(
                    balanceAmount = closingBal.toPlainString(),
                    balanceStatusLabel = "12. ${closingStatus.hindiLabel}"
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        FourPcEntry(
                            id = initialEntry?.id ?: "",
                            date = date,
                            totalBadaMaalCount = badaCount,
                            badaMaalWeight = badaWeight,
                            badaMaalRate = badaRate,
                            totalVeelMaalCount = veelCount,
                            veelMaalWeight = veelWeight,
                            veelMaalRate = veelRate,
                            paymentDate = paymentDate,
                            paymentAmount = paymentAmount,
                            createdAt = initialEntry?.createdAt ?: System.currentTimeMillis()
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
            ) {
                Text("हिसाब सहेजें", color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("रद्द करें") }
        }
    )
}
