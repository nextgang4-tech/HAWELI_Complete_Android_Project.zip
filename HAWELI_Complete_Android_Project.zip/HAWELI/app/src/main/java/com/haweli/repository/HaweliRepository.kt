package com.haweli.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.gson.GsonBuilder
import com.haweli.HaweliApplication
import com.haweli.calculations.AccountingCalculator
import com.haweli.database.DatabasePaths
import com.haweli.firebase.FirebaseClient
import com.haweli.models.*
import com.haweli.utils.DateAndFormatUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Central realtime repository for HAWELI.
 * Synchronizes all 8 modules across:
 * 1. Local persistent storage (`haweli_local_snapshot.json`) for instant load and 100% offline durability.
 * 2. Firebase Realtime Database (`https://haweli123-default-rtdb.firebaseio.com/`) via both the native
 *    Firebase Realtime Database SDK AND REST synchronization so multi-phone Admin-to-Viewer live sync
 *    works even when built directly on GitHub without a custom `google-services.json`.
 */
class HaweliRepository {

    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gson = GsonBuilder().create()

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _cities = MutableStateFlow<List<CityRecord>>(emptyList())
    val cities: StateFlow<List<CityRecord>> = _cities.asStateFlow()

    private val _parties = MutableStateFlow<List<PartyRecord>>(emptyList())
    val parties: StateFlow<List<PartyRecord>> = _parties.asStateFlow()

    private val _fourPcEntries = MutableStateFlow<List<FourPcEntry>>(emptyList())
    val fourPcEntries: StateFlow<List<FourPcEntry>> = _fourPcEntries.asStateFlow()

    private val _hyderabadEntries = MutableStateFlow<List<HyderabadEntry>>(emptyList())
    val hyderabadEntries: StateFlow<List<HyderabadEntry>> = _hyderabadEntries.asStateFlow()

    private val _chamdaOpeningStock = MutableStateFlow(ChamdaOpeningStock())
    val chamdaOpeningStock: StateFlow<ChamdaOpeningStock> = _chamdaOpeningStock.asStateFlow()

    private val _chamdaAwakEntries = MutableStateFlow<List<ChamdaAwakEntry>>(emptyList())
    val chamdaAwakEntries: StateFlow<List<ChamdaAwakEntry>> = _chamdaAwakEntries.asStateFlow()

    private val _chamdaBikriEntries = MutableStateFlow<List<ChamdaBikriEntry>>(emptyList())
    val chamdaBikriEntries: StateFlow<List<ChamdaBikriEntry>> = _chamdaBikriEntries.asStateFlow()

    private val _kenaEntries = MutableStateFlow<List<KenaEntry>>(emptyList())
    val kenaEntries: StateFlow<List<KenaEntry>> = _kenaEntries.asStateFlow()

    private val _potliEntries = MutableStateFlow<List<PotliEntry>>(emptyList())
    val potliEntries: StateFlow<List<PotliEntry>> = _potliEntries.asStateFlow()

    private val _vehicleEntries = MutableStateFlow<List<VehicleEntry>>(emptyList())
    val vehicleEntries: StateFlow<List<VehicleEntry>> = _vehicleEntries.asStateFlow()

    private val _payments = MutableStateFlow<List<PaymentRecord>>(emptyList())
    val payments: StateFlow<List<PaymentRecord>> = _payments.asStateFlow()

    private val _reports = MutableStateFlow<List<ReportMetadata>>(emptyList())
    val reports: StateFlow<List<ReportMetadata>> = _reports.asStateFlow()

    private val _dashboardTotals = MutableStateFlow(DashboardTotals())
    val dashboardTotals: StateFlow<DashboardTotals> = _dashboardTotals.asStateFlow()

    private val _pendingWriteCount = MutableStateFlow(0)
    val pendingWriteCount: StateFlow<Int> = _pendingWriteCount.asStateFlow()

    private var listenersAttached = false

    private fun localSnapshotFile(): File? {
        return try {
            File(HaweliApplication.appContext.filesDir, "haweli_local_snapshot.json")
        } catch (_: Exception) {
            null
        }
    }

    private fun loadLocalSnapshot() {
        try {
            val file = localSnapshotFile() ?: return
            if (!file.exists()) return
            val json = file.readText(Charsets.UTF_8)
            val payload = gson.fromJson(json, HaweliBackupPayload::class.java) ?: return
            applyPayloadToFlows(payload)
        } catch (_: Exception) {
        }
    }

    private fun saveLocalSnapshotAndSyncRemote() {
        val payload = buildBackupPayload()
        repoScope.launch {
            try {
                localSnapshotFile()?.writeText(gson.toJson(payload), Charsets.UTF_8)
            } catch (_: Exception) {
            }
            pushSnapshotToFirebaseRest(payload)
        }
    }

    private fun applyPayloadToFlows(payload: HaweliBackupPayload) {
        _settings.value = payload.settings
        _cities.value = payload.cities.values.sortedBy { it.name }
        val sortedParties = payload.parties.values.sortedBy { it.name }
        _parties.value = sortedParties
        _dashboardTotals.value = AccountingCalculator.calculateDashboardTotals(sortedParties)
        _fourPcEntries.value = payload.fourPcEntries.values.sortedWith(
            compareByDescending<FourPcEntry> { it.dateEpoch }.thenByDescending { it.createdAt }
        )
        _hyderabadEntries.value = payload.hyderabadEntries.values.sortedWith(
            compareByDescending<HyderabadEntry> { it.dateEpoch }.thenByDescending { it.createdAt }
        )
        _chamdaOpeningStock.value = payload.chamdaOpeningStock
        _chamdaAwakEntries.value = payload.chamdaAwakEntries.values.sortedWith(
            compareByDescending<ChamdaAwakEntry> { it.dateEpoch }.thenByDescending { it.createdAt }
        )
        _chamdaBikriEntries.value = payload.chamdaBikriEntries.values.sortedWith(
            compareByDescending<ChamdaBikriEntry> { it.dateEpoch }.thenByDescending { it.createdAt }
        )
        _kenaEntries.value = payload.kenaEntries.values.sortedWith(
            compareByDescending<KenaEntry> { it.dateEpoch }.thenByDescending { it.createdAt }
        )
        _potliEntries.value = payload.potliEntries.values.sortedWith(
            compareByDescending<PotliEntry> { it.dateEpoch }.thenByDescending { it.createdAt }
        )
        _vehicleEntries.value = payload.vehicleEntries.values.sortedWith(
            compareByDescending<VehicleEntry> { it.dateEpoch }.thenByDescending { it.createdAt }
        )
        _payments.value = payload.payments.values.sortedByDescending { it.dateEpoch }
        _reports.value = payload.reports.values.sortedByDescending { it.createdAt }
    }

    private fun pushSnapshotToFirebaseRest(payload: HaweliBackupPayload) {
        try {
            val url = URL("${DatabasePaths.DATABASE_URL}haweli/liveSnapshot.json")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "PUT"
                connectTimeout = 8000
                readTimeout = 8000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }
            conn.outputStream.use { out ->
                out.write(gson.toJson(payload).toByteArray(Charsets.UTF_8))
            }
            conn.responseCode
            conn.disconnect()
        } catch (_: Exception) {
        }
    }

    private fun pullSnapshotFromFirebaseRest() {
        try {
            val url = URL("${DatabasePaths.DATABASE_URL}haweli/liveSnapshot.json")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
            }
            if (conn.responseCode in 200..299) {
                val text = conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
                if (text.isNotBlank() && text != "null") {
                    val remotePayload = gson.fromJson(text, HaweliBackupPayload::class.java)
                    if (remotePayload != null && remotePayload.applicationName == "HAWELI") {
                        val localTime = _settings.value.updatedAt
                        if (remotePayload.backupTimestamp >= localTime || _parties.value.isEmpty()) {
                            applyPayloadToFlows(remotePayload)
                            localSnapshotFile()?.writeText(gson.toJson(remotePayload), Charsets.UTF_8)
                        }
                    }
                }
            }
            conn.disconnect()
        } catch (_: Exception) {
        }
    }

    fun startRealtimeListeners() {
        if (listenersAttached) return
        listenersAttached = true

        loadLocalSnapshot()

        // Start periodic background sync for Viewer/Admin multi-device realtime updates
        repoScope.launch {
            while (true) {
                pullSnapshotFromFirebaseRest()
                delay(6000L)
            }
        }

        try {
            FirebaseClient.ref(DatabasePaths.SETTINGS)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        snapshot.getValue(AppSettings::class.java)?.let {
                            _settings.value = it
                        }
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.CITIES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(CityRecord::class.java)
                        }.sortedBy { it.name }
                        if (list.isNotEmpty()) _cities.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.PARTIES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(PartyRecord::class.java)
                        }.sortedBy { it.name }
                        if (list.isNotEmpty()) {
                            _parties.value = list
                            _dashboardTotals.value = AccountingCalculator.calculateDashboardTotals(list)
                        }
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.FOUR_PC_PARTIES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(FourPcEntry::class.java)
                        }.sortedWith(compareByDescending<FourPcEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        if (list.isNotEmpty()) _fourPcEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.HYDERABAD_COMPANY)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(HyderabadEntry::class.java)
                        }.sortedWith(compareByDescending<HyderabadEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        if (list.isNotEmpty()) _hyderabadEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.CHAMDA_OPENING_STOCK)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        snapshot.getValue(ChamdaOpeningStock::class.java)?.let {
                            _chamdaOpeningStock.value = it
                        }
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.CHAMDA_PURCHASES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(ChamdaAwakEntry::class.java)
                        }.sortedWith(compareByDescending<ChamdaAwakEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        if (list.isNotEmpty()) _chamdaAwakEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.CHAMDA_SALES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(ChamdaBikriEntry::class.java)
                        }.sortedWith(compareByDescending<ChamdaBikriEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        if (list.isNotEmpty()) _chamdaBikriEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.KENA)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(KenaEntry::class.java)
                        }.sortedWith(compareByDescending<KenaEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        if (list.isNotEmpty()) _kenaEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.POTLI)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(PotliEntry::class.java)
                        }.sortedWith(compareByDescending<PotliEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        if (list.isNotEmpty()) _potliEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.VEHICLES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(VehicleEntry::class.java)
                        }.sortedWith(compareByDescending<VehicleEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        if (list.isNotEmpty()) _vehicleEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.PAYMENTS)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(PaymentRecord::class.java)
                        }.sortedByDescending { it.dateEpoch }
                        if (list.isNotEmpty()) _payments.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.REPORTS)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(ReportMetadata::class.java)
                        }.sortedByDescending { it.createdAt }
                        if (list.isNotEmpty()) _reports.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })
        } catch (_: Exception) {
        }
    }

    private fun refreshDashboardTotals() {
        _dashboardTotals.value = AccountingCalculator.calculateDashboardTotals(_parties.value)
        _settings.value = _settings.value.copy(updatedAt = System.currentTimeMillis())
        saveLocalSnapshotAndSyncRemote()
    }

    private fun trackWrite(refPath: String, value: Any?) {
        refreshDashboardTotals()
        try {
            FirebaseClient.ref(refPath).setValue(value)
        } catch (_: Exception) {
        }
    }

    private fun trackAtomicMultiPathUpdate(updates: Map<String, Any?>) {
        refreshDashboardTotals()
        try {
            FirebaseClient.ref(DatabasePaths.ROOT).updateChildren(updates)
        } catch (_: Exception) {
        }
    }

    // =========================================================================
    // 1. CITY MANAGEMENT (शहर प्रबंधन)
    // =========================================================================

    fun saveCity(cityName: String, existingId: String? = null) {
        val cleanName = cityName.trim()
        if (cleanName.isEmpty()) return
        val id = existingId ?: UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val existing = _cities.value.find { it.id == id }
        val record = CityRecord(
            id = id,
            name = cleanName,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now
        )
        _cities.value = (_cities.value.filter { it.id != id } + record).sortedBy { it.name }
        trackWrite("${DatabasePaths.CITIES}/$id", record)
    }

    fun deleteCity(cityId: String) {
        _cities.value = _cities.value.filter { it.id != cityId }
        _parties.value = _parties.value.filter { it.cityId != cityId }
        _fourPcEntries.value = _fourPcEntries.value.filter { it.cityId != cityId }
        val updates = mutableMapOf<String, Any?>("cities/$cityId" to null)
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 2. PARTY MANAGEMENT (पार्टी प्रबंधन - सभी मॉड्यूल)
    // =========================================================================

    fun saveParty(
        module: String,
        name: String,
        cityId: String = "",
        cityName: String = "",
        phone: String = "",
        openingBalance: String = "0.00",
        existingId: String? = null
    ) {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return
        val id = existingId ?: UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val existing = _parties.value.find { it.id == id }
        val openBalDec = AccountingCalculator.parseDecimal(openingBalance)
        val openBalFormatted = AccountingCalculator.formatDecimal(openBalDec)

        val baseParty = PartyRecord(
            id = id,
            module = module,
            cityId = cityId,
            cityName = cityName,
            name = cleanName,
            phone = phone.trim(),
            openingBalance = openBalFormatted,
            currentBalance = existing?.currentBalance ?: openBalFormatted,
            balanceStatus = existing?.balanceStatus ?: resolveStatusLabel(module, openBalDec),
            createdAt = existing?.createdAt ?: now,
            updatedAt = now
        )

        _parties.value = (_parties.value.filter { it.id != id } + baseParty).sortedBy { it.name }

        val updates = mutableMapOf<String, Any?>("parties/$id" to baseParty)
        if (module == "CHAMDA_SALES") {
            updates["chamda/parties/$id"] = baseParty
        }
        trackAtomicMultiPathUpdate(updates)
        recalculateAndPersistPartyLedger(baseParty)
    }

    fun deleteParty(party: PartyRecord) {
        _parties.value = _parties.value.filter { it.id != party.id }
        _fourPcEntries.value = _fourPcEntries.value.filter { it.partyId != party.id }
        _hyderabadEntries.value = _hyderabadEntries.value.filter { it.partyId != party.id }
        _chamdaBikriEntries.value = _chamdaBikriEntries.value.filter { it.partyId != party.id }
        _kenaEntries.value = _kenaEntries.value.filter { it.partyId != party.id }
        _potliEntries.value = _potliEntries.value.filter { it.partyId != party.id }
        _payments.value = _payments.value.filter { it.partyId != party.id }

        val updates = mutableMapOf<String, Any?>("parties/${party.id}" to null)
        trackAtomicMultiPathUpdate(updates)
    }

    private fun resolveStatusLabel(module: String, balance: BigDecimal): String {
        return if (module == "FOUR_PC") {
            AccountingCalculator.resolvePayableStatus(balance).hindiLabel
        } else {
            AccountingCalculator.resolveReceivableStatus(balance).hindiLabel
        }
    }

    private fun updateLocalPartyState(updatedParty: PartyRecord) {
        _parties.value = (_parties.value.filter { it.id != updatedParty.id } + updatedParty).sortedBy { it.name }
    }

    // =========================================================================
    // 3. 4PC PARTY LEDGER ENTRIES (4PC पार्टी हिसाब)
    // =========================================================================

    fun saveFourPcEntry(party: PartyRecord, draft: FourPcEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            cityId = party.cityId,
            cityName = party.cityName,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _fourPcEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistFourPcChain(party, currentEntries)
    }

    fun deleteFourPcEntry(party: PartyRecord, entryId: String) {
        val remaining = _fourPcEntries.value.filter { it.partyId == party.id && it.id != entryId }
        _fourPcEntries.value = _fourPcEntries.value.filter { it.id != entryId }
        _payments.value = _payments.value.filter { it.id != entryId }
        persistFourPcChain(party, remaining)
    }

    private fun persistFourPcChain(party: PartyRecord, entries: List<FourPcEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculateFourPcPartyChain(
            party.openingBalance,
            entries
        )
        _fourPcEntries.value = (_fourPcEntries.value.filter { it.partyId != party.id } + recalculated)
            .sortedWith(compareByDescending<FourPcEntry> { it.dateEpoch }.thenByDescending { it.createdAt })

        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["fourPcParties/${e.id}"] = e
            val payRec = buildPaymentRecord(
                id = e.id,
                module = "FOUR_PC",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.paymentAmount,
                type = "PAID"
            )
            updates["payments/${e.id}"] = payRec
            _payments.value = _payments.value.filter { it.id != e.id } + listOfNotNull(payRec)
        }
        val status = AccountingCalculator.resolvePayableStatus(finalBal).hindiLabel
        val updatedParty = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        updateLocalPartyState(updatedParty)
        updates["parties/${party.id}"] = updatedParty
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 4. HYDERABAD COMPANY ENTRIES (हैदराबाद कंपनी हिसाब)
    // =========================================================================

    fun saveHyderabadEntry(party: PartyRecord, draft: HyderabadEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _hyderabadEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistHyderabadChain(party, currentEntries)
    }

    fun deleteHyderabadEntry(party: PartyRecord, entryId: String) {
        val remaining = _hyderabadEntries.value.filter { it.partyId == party.id && it.id != entryId }
        _hyderabadEntries.value = _hyderabadEntries.value.filter { it.id != entryId }
        _payments.value = _payments.value.filter { it.id != entryId }
        persistHyderabadChain(party, remaining)
    }

    private fun persistHyderabadChain(party: PartyRecord, entries: List<HyderabadEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculateHyderabadPartyChain(
            party.openingBalance,
            entries
        )
        _hyderabadEntries.value = (_hyderabadEntries.value.filter { it.partyId != party.id } + recalculated)
            .sortedWith(compareByDescending<HyderabadEntry> { it.dateEpoch }.thenByDescending { it.createdAt })

        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["hyderabadCompany/${e.id}"] = e
            val payRec = buildPaymentRecord(
                id = e.id,
                module = "HYDERABAD",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
            updates["payments/${e.id}"] = payRec
            _payments.value = _payments.value.filter { it.id != e.id } + listOfNotNull(payRec)
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        val updatedParty = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        updateLocalPartyState(updatedParty)
        updates["parties/${party.id}"] = updatedParty
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 5. CHAMDA MANAGEMENT (चमड़ा आवक एवं चमड़ा बिक्री)
    // =========================================================================

    fun saveChamdaOpeningStock(badaCount: String, veelCount: String) {
        val stock = ChamdaOpeningStock(
            openingBadaChamda = AccountingCalculator.parseDecimal(badaCount).setScale(0).toPlainString(),
            openingVeelChamda = AccountingCalculator.parseDecimal(veelCount).setScale(0).toPlainString(),
            updatedAt = System.currentTimeMillis()
        )
        _chamdaOpeningStock.value = stock
        trackWrite(DatabasePaths.CHAMDA_OPENING_STOCK, stock)
    }

    fun saveChamdaAwakEntry(draft: ChamdaAwakEntry) {
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val badaCount = AccountingCalculator.parseDecimal(draft.badaChamdaCount).setScale(0)
        val veelCount = AccountingCalculator.parseDecimal(draft.veelChamdaCount).setScale(0)
        val totalCount = badaCount.add(veelCount)
        val badaWeight = AccountingCalculator.parseDecimal(draft.badaChamdaWeight)
        val veelWeight = AccountingCalculator.parseDecimal(draft.veelChamdaWeight)
        val totalWeight = badaWeight.add(veelWeight)

        val record = draft.copy(
            id = id,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            year = DateAndFormatUtils.extractYear(normalizedDate),
            badaChamdaCount = badaCount.toPlainString(),
            badaChamdaWeight = AccountingCalculator.formatDecimal(badaWeight),
            veelChamdaCount = veelCount.toPlainString(),
            veelChamdaWeight = AccountingCalculator.formatDecimal(veelWeight),
            totalChamdaCount = totalCount.toPlainString(),
            totalWeight = AccountingCalculator.formatDecimal(totalWeight),
            updatedAt = System.currentTimeMillis()
        )

        _chamdaAwakEntries.value = (_chamdaAwakEntries.value.filter { it.id != id } + record)
            .sortedWith(compareByDescending<ChamdaAwakEntry> { it.dateEpoch }.thenByDescending { it.createdAt })

        val updates = mapOf(
            "chamda/purchases/$id" to record,
            "purchases/$id" to record
        )
        trackAtomicMultiPathUpdate(updates)
    }

    fun deleteChamdaAwakEntry(entryId: String) {
        _chamdaAwakEntries.value = _chamdaAwakEntries.value.filter { it.id != entryId }
        val updates = mapOf(
            "chamda/purchases/$entryId" to null,
            "purchases/$entryId" to null
        )
        trackAtomicMultiPathUpdate(updates)
    }

    fun wouldChamdaStockBecomeNegative(draft: ChamdaBikriEntry): Pair<Boolean, String> {
        val currentMonth = DateAndFormatUtils.currentMonthYear()
        val otherSales = _chamdaBikriEntries.value.filter { it.id != draft.id }
        val candidateSales = otherSales + draft
        val summaryAfter = AccountingCalculator.calculateChamdaStockSummary(
            openingStock = _chamdaOpeningStock.value,
            allAwak = _chamdaAwakEntries.value,
            allBikri = candidateSales,
            targetMonthYear = currentMonth
        )
        val closeBada = AccountingCalculator.parseDecimal(summaryAfter.closingBadaStock)
        val closeVeel = AccountingCalculator.parseDecimal(summaryAfter.closingVeelStock)
        return if (closeBada < BigDecimal.ZERO || closeVeel < BigDecimal.ZERO) {
            Pair(
                true,
                "चेतावनी: इस बिक्री के बाद स्टॉक नकारात्मक हो जाएगा (बचा बड़ा चमड़ा: ${summaryAfter.closingBadaStock}, बचा वील चमड़ा: ${summaryAfter.closingVeelStock})। क्या आप फिर भी एडमिन के रूप में इसे सहेजना चाहते हैं?"
            )
        } else {
            Pair(false, "")
        }
    }

    fun saveChamdaBikriEntry(party: PartyRecord, draft: ChamdaBikriEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            year = DateAndFormatUtils.extractYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _chamdaBikriEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistChamdaBikriChain(party, currentEntries)
    }

    fun deleteChamdaBikriEntry(party: PartyRecord, entryId: String) {
        val remaining = _chamdaBikriEntries.value.filter { it.partyId == party.id && it.id != entryId }
        _chamdaBikriEntries.value = _chamdaBikriEntries.value.filter { it.id != entryId }
        _payments.value = _payments.value.filter { it.id != entryId }
        persistChamdaBikriChain(party, remaining)
    }

    private fun persistChamdaBikriChain(party: PartyRecord, entries: List<ChamdaBikriEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculateChamdaBikriPartyChain(
            party.openingBalance,
            entries
        )
        _chamdaBikriEntries.value = (_chamdaBikriEntries.value.filter { it.partyId != party.id } + recalculated)
            .sortedWith(compareByDescending<ChamdaBikriEntry> { it.dateEpoch }.thenByDescending { it.createdAt })

        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["chamda/sales/${e.id}"] = e
            updates["sales/${e.id}"] = e
            val payRec = buildPaymentRecord(
                id = e.id,
                module = "CHAMDA_SALES",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
            updates["payments/${e.id}"] = payRec
            _payments.value = _payments.value.filter { it.id != e.id } + listOfNotNull(payRec)
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        val updatedParty = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        updateLocalPartyState(updatedParty)
        updates["parties/${party.id}"] = updatedParty
        updates["chamda/parties/${party.id}"] = updatedParty
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 6. KENA MANAGEMENT (केना हिसाब)
    // =========================================================================

    fun saveKenaEntry(party: PartyRecord, draft: KenaEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _kenaEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistKenaChain(party, currentEntries)
    }

    fun deleteKenaEntry(party: PartyRecord, entryId: String) {
        val remaining = _kenaEntries.value.filter { it.partyId == party.id && it.id != entryId }
        _kenaEntries.value = _kenaEntries.value.filter { it.id != entryId }
        _payments.value = _payments.value.filter { it.id != entryId }
        persistKenaChain(party, remaining)
    }

    private fun persistKenaChain(party: PartyRecord, entries: List<KenaEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculateKenaPartyChain(
            party.openingBalance,
            entries
        )
        _kenaEntries.value = (_kenaEntries.value.filter { it.partyId != party.id } + recalculated)
            .sortedWith(compareByDescending<KenaEntry> { it.dateEpoch }.thenByDescending { it.createdAt })

        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["kena/${e.id}"] = e
            val payRec = buildPaymentRecord(
                id = e.id,
                module = "KENA",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
            updates["payments/${e.id}"] = payRec
            _payments.value = _payments.value.filter { it.id != e.id } + listOfNotNull(payRec)
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        val updatedParty = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        updateLocalPartyState(updatedParty)
        updates["parties/${party.id}"] = updatedParty
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 7. POTLI MANAGEMENT (पोटली हिसाब)
    // =========================================================================

    fun savePotliEntry(party: PartyRecord, draft: PotliEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _potliEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistPotliChain(party, currentEntries)
    }

    fun deletePotliEntry(party: PartyRecord, entryId: String) {
        val remaining = _potliEntries.value.filter { it.partyId == party.id && it.id != entryId }
        _potliEntries.value = _potliEntries.value.filter { it.id != entryId }
        _payments.value = _payments.value.filter { it.id != entryId }
        persistPotliChain(party, remaining)
    }

    private fun persistPotliChain(party: PartyRecord, entries: List<PotliEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculatePotliPartyChain(
            party.openingBalance,
            entries
        )
        _potliEntries.value = (_potliEntries.value.filter { it.partyId != party.id } + recalculated)
            .sortedWith(compareByDescending<PotliEntry> { it.dateEpoch }.thenByDescending { it.createdAt })

        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["potli/${e.id}"] = e
            val payRec = buildPaymentRecord(
                id = e.id,
                module = "POTLI",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
            updates["payments/${e.id}"] = payRec
            _payments.value = _payments.value.filter { it.id != e.id } + listOfNotNull(payRec)
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        val updatedParty = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        updateLocalPartyState(updatedParty)
        updates["parties/${party.id}"] = updatedParty
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 8. OBAD TO HYDERABAD GAADI (ओबाद से हैदराबाद गाड़ी)
    // =========================================================================

    fun saveVehicleEntry(draft: VehicleEntry) {
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val enriched = AccountingCalculator.enrichVehicleEntry(
            draft.copy(
                id = id,
                date = normalizedDate,
                vehicleNumber = draft.vehicleNumber.trim().uppercase(),
                updatedAt = System.currentTimeMillis()
            )
        )
        _vehicleEntries.value = (_vehicleEntries.value.filter { it.id != id } + enriched)
            .sortedWith(compareByDescending<VehicleEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
        trackWrite("${DatabasePaths.VEHICLES}/$id", enriched)
    }

    fun deleteVehicleEntry(entryId: String) {
        _vehicleEntries.value = _vehicleEntries.value.filter { it.id != entryId }
        trackWrite("${DatabasePaths.VEHICLES}/$entryId", null)
    }

    // =========================================================================
    // 9. SETTINGS & REPORT METADATA LOGGING
    // =========================================================================

    fun saveAppSettings(newSettings: AppSettings) {
        val updated = newSettings.copy(updatedAt = System.currentTimeMillis())
        _settings.value = updated
        trackWrite(DatabasePaths.SETTINGS, updated)
    }

    fun recordGeneratedReport(metadata: ReportMetadata) {
        val id = metadata.id.ifBlank { UUID.randomUUID().toString() }
        val rec = metadata.copy(id = id)
        _reports.value = (_reports.value.filter { it.id != id } + rec).sortedByDescending { it.createdAt }
        trackWrite("${DatabasePaths.REPORTS}/$id", rec)
    }

    private fun recalculateAndPersistPartyLedger(party: PartyRecord) {
        when (party.module) {
            "FOUR_PC" -> persistFourPcChain(
                party,
                _fourPcEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
            "HYDERABAD" -> persistHyderabadChain(
                party,
                _hyderabadEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
            "CHAMDA_SALES" -> persistChamdaBikriChain(
                party,
                _chamdaBikriEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
            "KENA" -> persistKenaChain(
                party,
                _kenaEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
            "POTLI" -> persistPotliChain(
                party,
                _potliEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
        }
    }

    private fun buildPaymentRecord(
        id: String,
        module: String,
        partyId: String,
        partyName: String,
        paymentDate: String,
        amount: String,
        type: String
    ): PaymentRecord? {
        val amtDec = AccountingCalculator.parseDecimal(amount)
        if (amtDec.compareTo(BigDecimal.ZERO) <= 0) return null
        return PaymentRecord(
            id = id,
            sourceEntryId = id,
            module = module,
            partyId = partyId,
            partyName = partyName,
            paymentDate = paymentDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(paymentDate),
            amount = AccountingCalculator.formatDecimal(amtDec),
            paymentType = type,
            updatedAt = System.currentTimeMillis()
        )
    }

    // =========================================================================
    // 10. FULL SNAPSHOT EXPORT & RESTORE FOR JSON BACKUP
    // =========================================================================

    fun buildBackupPayload(): HaweliBackupPayload {
        val now = System.currentTimeMillis()
        return HaweliBackupPayload(
            backupVersion = 1,
            applicationName = "HAWELI",
            backupTimestamp = now,
            backupDateFormatted = DateAndFormatUtils.formatTimestamp(now),
            settings = _settings.value,
            cities = _cities.value.associateBy { it.id },
            parties = _parties.value.associateBy { it.id },
            fourPcEntries = _fourPcEntries.value.associateBy { it.id },
            hyderabadEntries = _hyderabadEntries.value.associateBy { it.id },
            chamdaOpeningStock = _chamdaOpeningStock.value,
            chamdaAwakEntries = _chamdaAwakEntries.value.associateBy { it.id },
            chamdaBikriEntries = _chamdaBikriEntries.value.associateBy { it.id },
            kenaEntries = _kenaEntries.value.associateBy { it.id },
            potliEntries = _potliEntries.value.associateBy { it.id },
            vehicleEntries = _vehicleEntries.value.associateBy { it.id },
            payments = _payments.value.associateBy { it.id },
            reports = _reports.value.associateBy { it.id }
        )
    }

    fun restoreFromBackupPayload(payload: HaweliBackupPayload) {
        applyPayloadToFlows(payload)
        val updates = mutableMapOf<String, Any?>(
            "settings" to payload.settings,
            "cities" to payload.cities,
            "parties" to payload.parties,
            "fourPcParties" to payload.fourPcEntries,
            "hyderabadCompany" to payload.hyderabadEntries,
            "chamda/openingStock" to payload.chamdaOpeningStock,
            "chamda/purchases" to payload.chamdaAwakEntries,
            "purchases" to payload.chamdaAwakEntries,
            "chamda/sales" to payload.chamdaBikriEntries,
            "sales" to payload.chamdaBikriEntries,
            "chamda/parties" to payload.parties.filterValues { it.module == "CHAMDA_SALES" },
            "kena" to payload.kenaEntries,
            "potli" to payload.potliEntries,
            "vehicles" to payload.vehicleEntries,
            "payments" to payload.payments,
            "reports" to payload.reports
        )
        trackAtomicMultiPathUpdate(updates)
    }
}
