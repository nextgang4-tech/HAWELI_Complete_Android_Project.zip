package com.haweli.firebase

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.functions.FirebaseFunctions
import com.haweli.HaweliApplication
import com.haweli.database.DatabasePaths
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Singleton wrapper configuring Firebase Realtime Database with offline persistence,
 * disk cache size, and network/realtime connection state monitoring for
 * https://haweli123-default-rtdb.firebaseio.com/.
 */
object FirebaseClient {

    @Volatile
    private var persistenceInitialized = false

    val database: FirebaseDatabase by lazy {
        HaweliApplication.ensureFirebaseInitialized(HaweliApplication.appContext)
        val db = FirebaseDatabase.getInstance(DatabasePaths.DATABASE_URL)
        if (!persistenceInitialized) {
            try {
                db.setPersistenceEnabled(true)
                db.setPersistenceCacheSizeBytes(50L * 1024L * 1024L)
                db.getReference(DatabasePaths.ROOT).keepSynced(true)
            } catch (_: Exception) {
            }
            persistenceInitialized = true
        }
        db
    }

    val auth: FirebaseAuth by lazy {
        HaweliApplication.ensureFirebaseInitialized(HaweliApplication.appContext)
        FirebaseAuth.getInstance()
    }

    val functions: FirebaseFunctions by lazy {
        HaweliApplication.ensureFirebaseInitialized(HaweliApplication.appContext)
        FirebaseFunctions.getInstance()
    }

    fun rootRef(): DatabaseReference = database.getReference(DatabasePaths.ROOT)

    fun ref(path: String): DatabaseReference = database.getReference(path)

    /**
     * Emits true when the device has active internet or Firebase RTDB socket connection.
     */
    fun observeConnectionStatus(): Flow<Boolean> = callbackFlow {
        val context = try {
            HaweliApplication.appContext
        } catch (_: Exception) {
            null
        }

        val cm = context?.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        fun isNetworkOnline(): Boolean {
            if (cm == null) return true
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }

        trySend(isNetworkOnline())

        val netCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(true)
            }

            override fun onLost(network: Network) {
                trySend(isNetworkOnline())
            }
        }

        try {
            cm?.registerNetworkCallback(NetworkRequest.Builder().build(), netCallback)
        } catch (_: Exception) {
        }

        val connectedRef = try {
            database.getReference(".info/connected")
        } catch (e: Exception) {
            null
        }

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val rtdbConnected = snapshot.getValue(Boolean::class.java) ?: false
                trySend(rtdbConnected || isNetworkOnline())
            }

            override fun onCancelled(error: DatabaseError) {
                trySend(isNetworkOnline())
            }
        }
        connectedRef?.addValueEventListener(listener)

        awaitClose {
            try {
                cm?.unregisterNetworkCallback(netCallback)
            } catch (_: Exception) {
            }
            connectedRef?.removeEventListener(listener)
        }
    }
}
