package com.haweli.database

/**
 * Organized Firebase Realtime Database paths under https://haweli123-default-rtdb.firebaseio.com/
 */
object DatabasePaths {
    const val DATABASE_URL = "https://haweli123-default-rtdb.firebaseio.com/"

    const val ROOT = "haweli"
    const val SETTINGS = "$ROOT/settings"
    const val USERS = "$ROOT/users"
    const val CITIES = "$ROOT/cities"
    const val PARTIES = "$ROOT/parties"
    const val FOUR_PC_PARTIES = "$ROOT/fourPcParties"
    const val HYDERABAD_COMPANY = "$ROOT/hyderabadCompany"
    const val CHAMDA = "$ROOT/chamda"
    const val CHAMDA_OPENING_STOCK = "$CHAMDA/openingStock"
    const val CHAMDA_PURCHASES = "$CHAMDA/purchases"
    const val CHAMDA_SALES = "$CHAMDA/sales"
    const val CHAMDA_PARTIES = "$CHAMDA/parties"
    const val PURCHASES = "$ROOT/purchases"
    const val SALES = "$ROOT/sales"
    const val KENA = "$ROOT/kena"
    const val POTLI = "$ROOT/potli"
    const val VEHICLES = "$ROOT/vehicles"
    const val PAYMENTS = "$ROOT/payments"
    const val REPORTS = "$ROOT/reports"
}
