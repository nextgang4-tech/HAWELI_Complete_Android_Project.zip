package com.haweli

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.haweli.firebase.AuthManager
import com.haweli.firebase.FirebaseClient
import com.haweli.models.*
import com.haweli.repository.HaweliRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * Shared application ViewModel coordinating Firebase Realtime Database streams,
 * Admin/Viewer role authentication, and accounting actions across all 8 modules.
 */
class HaweliViewModel : ViewModel() {

    val repository = HaweliRepository()
    val authManager = AuthManager()

    val isConnected: StateFlow<Boolean> = FirebaseClient.observeConnectionStatus()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val accessRole: StateFlow<AccessRole> = authManager.accessRole
    val mustChangePassword: StateFlow<Boolean> = authManager.mustChangePassword
    val authStatusMessage: StateFlow<String> = authManager.authStatusMessage

    val settings: StateFlow<AppSettings> = repository.settings
    val cities: StateFlow<List<CityRecord>> = repository.cities
    val parties: StateFlow<List<PartyRecord>> = repository.parties
    val fourPcEntries: StateFlow<List<FourPcEntry>> = repository.fourPcEntries
    val hyderabadEntries: StateFlow<List<HyderabadEntry>> = repository.hyderabadEntries
    val chamdaOpeningStock: StateFlow<ChamdaOpeningStock> = repository.chamdaOpeningStock
    val chamdaAwakEntries: StateFlow<List<ChamdaAwakEntry>> = repository.chamdaAwakEntries
    val chamdaBikriEntries: StateFlow<List<ChamdaBikriEntry>> = repository.chamdaBikriEntries
    val kenaEntries: StateFlow<List<KenaEntry>> = repository.kenaEntries
    val potliEntries: StateFlow<List<PotliEntry>> = repository.potliEntries
    val vehicleEntries: StateFlow<List<VehicleEntry>> = repository.vehicleEntries
    val payments: StateFlow<List<PaymentRecord>> = repository.payments
    val reports: StateFlow<List<ReportMetadata>> = repository.reports
    val dashboardTotals: StateFlow<DashboardTotals> = repository.dashboardTotals
    val pendingWriteCount: StateFlow<Int> = repository.pendingWriteCount

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _authBusy = MutableStateFlow(false)
    val authBusy: StateFlow<Boolean> = _authBusy.asStateFlow()

    init {
        viewModelScope.launch {
            authManager.initializeSession()
            repository.startRealtimeListeners()
        }
    }

    fun clearAuthError() {
        _authError.value = null
    }

    fun loginAdmin(username: String, password: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val result = authManager.loginAsAdmin(username, password)
            _authBusy.value = false
            result.onSuccess {
                onSuccess()
            }.onFailure { err ->
                _authError.value = err.message
            }
        }
    }

    fun changeAdminPassword(
        currentPass: String,
        newPass: String,
        confirmPass: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val result = authManager.changeAdminPassword(currentPass, newPass, confirmPass)
            _authBusy.value = false
            result.onSuccess {
                onSuccess()
            }.onFailure { err ->
                _authError.value = err.message
            }
        }
    }

    fun logoutAdmin() {
        viewModelScope.launch {
            authManager.logoutAdminToViewer()
        }
    }
}
