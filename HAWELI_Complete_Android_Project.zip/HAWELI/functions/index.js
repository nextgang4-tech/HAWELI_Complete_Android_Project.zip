const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp({
  databaseURL: "https://haweli123-default-rtdb.firebaseio.com/"
});

const ADMIN_EMAIL = "haweli@haweli-accounting.local";

/**
 * Provisions the initial Admin account ("Haweli" / "Haweli") on the backend if it does not exist yet,
 * sets the custom claim { admin: true, mustChangePassword: true }, and records the role in
 * /haweli/users/{uid} without storing any plaintext password in Realtime Database.
 */
exports.provisionInitialAdmin = functions.https.onCall(async (data, context) => {
  const db = admin.database();
  const provisionSnap = await db.ref("haweli/settings/adminProvisioned").once("value");

  if (provisionSnap.exists() && provisionSnap.val() === true) {
    return {
      provisioned: true,
      message: "एडमिन खाता पहले से सुरक्षित रूप से पंजीकृत है।"
    };
  }

  const initialPassword = process.env.HAWELI_INITIAL_PASSWORD || "Haweli#2026";
  let userRecord;
  try {
    userRecord = await admin.auth().getUserByEmail(ADMIN_EMAIL);
  } catch (err) {
    if (err.code === "auth/user-not-found") {
      userRecord = await admin.auth().createUser({
        email: ADMIN_EMAIL,
        password: initialPassword,
        displayName: "Haweli",
        emailVerified: true
      });
    } else {
      throw new functions.https.HttpsError("internal", err.message);
    }
  }

  await admin.auth().setCustomUserClaims(userRecord.uid, {
    admin: true,
    username: "Haweli",
    mustChangePassword: true
  });

  await db.ref(`haweli/users/${userRecord.uid}`).set({
    uid: userRecord.uid,
    username: "Haweli",
    role: "ADMIN",
    mustChangePassword: true,
    updatedAt: admin.database.ServerValue.TIMESTAMP
  });

  await db.ref("haweli/settings/adminProvisioned").set(true);

  return {
    provisioned: true,
    uid: userRecord.uid,
    message: "प्रारंभिक एडमिन खाता सफलतापूर्वक तैयार किया गया।"
  };
});

/**
 * Verifies and refreshes custom claims for an authenticated admin user,
 * ensuring only legitimate admin accounts receive write permissions.
 */
exports.verifyAdminRole = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "कृपया पहले एडमिन लॉगिन करें।"
    );
  }

  const uid = context.auth.uid;
  const userRecord = await admin.auth().getUser(uid);
  const db = admin.database();
  const roleSnap = await db.ref(`haweli/users/${uid}`).once("value");
  const roleData = roleSnap.val() || {};

  const isEmailAdmin = userRecord.email && userRecord.email.toLowerCase() === ADMIN_EMAIL;
  const isClaimAdmin = Boolean(userRecord.customClaims && userRecord.customClaims.admin === true);
  const isDbAdmin = roleData.role === "ADMIN";

  if (!isEmailAdmin && !isClaimAdmin && !isDbAdmin) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "यह खाता एडमिन के रूप में अधिकृत नहीं है।"
    );
  }

  const mustChangePassword =
    roleData.mustChangePassword !== undefined ? Boolean(roleData.mustChangePassword) : true;

  await admin.auth().setCustomUserClaims(uid, {
    admin: true,
    username: "Haweli",
    mustChangePassword: mustChangePassword
  });

  await db.ref(`haweli/users/${uid}`).update({
    uid: uid,
    username: "Haweli",
    role: "ADMIN",
    mustChangePassword: mustChangePassword,
    lastVerifiedAt: admin.database.ServerValue.TIMESTAMP
  });

  return {
    isAdmin: true,
    mustChangePassword: mustChangePassword
  };
});

/**
 * Marks the admin's forced initial password change as completed after Firebase Auth password update.
 */
exports.completeInitialPasswordChange = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "अनधिकृत अनुरोध।"
    );
  }

  const uid = context.auth.uid;
  const userRecord = await admin.auth().getUser(uid);
  const isAdmin =
    (userRecord.customClaims && userRecord.customClaims.admin === true) ||
    (userRecord.email && userRecord.email.toLowerCase() === ADMIN_EMAIL);

  if (!isAdmin) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "केवल एडमिन पासवर्ड स्थिति अपडेट कर सकता है।"
    );
  }

  await admin.auth().setCustomUserClaims(uid, {
    admin: true,
    username: "Haweli",
    mustChangePassword: false
  });

  const db = admin.database();
  await db.ref(`haweli/users/${uid}`).update({
    mustChangePassword: false,
    passwordChangedAt: admin.database.ServerValue.TIMESTAMP
  });

  return {
    success: true,
    mustChangePassword: false,
    message: "पासवर्ड सफलतापूर्वक बदल दिया गया है।"
  };
});
