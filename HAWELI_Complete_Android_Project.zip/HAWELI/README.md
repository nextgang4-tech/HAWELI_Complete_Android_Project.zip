# HAWELI (हवेली) — संपूर्ण एंड्रॉइड बिज़नेस अकाउंटिंग एवं प्रबंधन एप्लीकेशन

**HAWELI** एक पूर्णतः कार्यशील, प्रोडक्शन-रेडी एंड्रॉइड बिज़नेस अकाउंटिंग एप्लीकेशन है, जिसे **Kotlin**, **Jetpack Compose (Material 3)**, **Firebase Realtime Database**, **Firebase Authentication**, **Firebase Cloud Functions**, और **Android Native PDF Engine** का उपयोग करके बनाया गया है।

---

## 1. प्रोजेक्ट की संरचना (GitHub Project Structure)

```text
HAWELI/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/haweli/
│       │   │   ├── HaweliApplication.kt
│       │   │   ├── MainActivity.kt
│       │   │   ├── HaweliViewModel.kt
│       │   │   ├── ui/
│       │   │   │   ├── theme/HaweliTheme.kt
│       │   │   │   ├── components/CommonComponents.kt
│       │   │   │   └── screens/
│       │   │   │       ├── HomeDashboardScreen.kt
│       │   │   │       ├── FourPcPartyScreen.kt
│       │   │   │       ├── HyderabadCompanyScreen.kt
│       │   │   │       ├── ChamdaScreen.kt
│       │   │   │       ├── KenaScreen.kt
│       │   │   │       ├── PotliScreen.kt
│       │   │   │       ├── ObadHyderabadGaadiScreen.kt
│       │   │   │       ├── ReportsScreen.kt
│       │   │   │       └── SettingsScreen.kt
│       │   │   ├── navigation/HaweliNavigation.kt
│       │   │   ├── admin/AdminAccessGuard.kt
│       │   │   ├── viewer/ViewerModeBanner.kt
│       │   │   ├── models/AccountingModels.kt
│       │   │   ├── repository/HaweliRepository.kt
│       │   │   ├── firebase/
│       │   │   │   ├── FirebaseClient.kt
│       │   │   │   └── AuthManager.kt
│       │   │   ├── database/DatabasePaths.kt
│       │   │   ├── calculations/AccountingCalculator.kt
│       │   │   ├── pdf/HaweliPdfGenerator.kt
│       │   │   ├── backup/BackupManager.kt
│       │   │   └── utils/
│       │   │       ├── DateAndFormatUtils.kt
│       │   │       └── AppShareUtils.kt
│       │   └── res/
│       │       ├── values/strings.xml
│       │       ├── values/themes.xml
│       │       └── xml/file_paths.xml
│       └── test/java/com/haweli/calculations/AccountingCalculatorTest.kt
├── functions/
│   ├── index.js
│   └── package.json
├── firebase/
│   ├── database.rules.json
│   └── database.indexes.json
├── .github/workflows/
│   └── android-build.yml
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── README.md
```

---

## 2. प्रमुख विशेषताएं और 8 मुख्य मॉड्यूल (हिंदी में)

1. **होम डैशबोर्ड (Home Dashboard)**:
   - **कार्ड 1 (कुल आना)**: हैदराबाद कंपनी, चमड़ा बिक्री, केना और पोटली से सभी पार्टियों की कुल लेनदारी (बिना दोहरी गिनती के)।
   - **कार्ड 2 (कुल देना)**: 4PC पार्टी एवं अन्य विभागों की कुल देनदारी।
   - **वैश्विक खोज (Global Search)**: होम स्क्रीन से सीधे किसी भी पार्टी, शहर या गाड़ी नंबर को खोजें।
2. **4PC पार्टी प्रबंधन**:
   - `4PC पार्टी → शहर → पार्टी का नाम → हिसाब` पदानुक्रम।
   - सभी 12 फ़ील्ड्स, लाल रंग में भुगतान, और `बाकी देना` / `एडवांस` / `हिसाब बराबर` की स्वचालित गणना।
3. **हैदराबाद कंपनी**:
   - पार्टी-वार बड़ा माल और वील माल का हिसाब (14 फ़ील्ड्स), लाल रंग में प्राप्त भुगतान, और `बाकी आना` / `एडवांस` / `हिसाब बराबर` स्थिति।
4. **चमड़ा प्रबंधन (चमड़ा आवक एवं चमड़ा बिक्री)**:
   - **A. चमड़ा आवक**: दैनिक प्रविष्टियां, मासिक बड़ा/वील चमड़ा और कुल वजन का स्वचालित जोड़।
   - **B. चमड़ा बिक्री**: ग्राहक पार्टियों को बिक्री और स्टॉक फॉर्मूला (`Opening Stock + Total Received - Total Sold = Closing Stock`)। स्टॉक नकारात्मक होने पर एडमिन चेतावनी संवाद।
5. **केना (Kena Management)**:
   - तारीख-वार दैनिक केना एंट्री, मासिक कुल केना और पार्टी-वार बकाया।
6. **पोटली (Potli Management)**:
   - तारीख-वार दैनिक पोटली एंट्री, मासिक कुल पोटली और पार्टी-वार बकाया।
7. **ओबाद से हैदराबाद गाड़ी प्रबंधन**:
   - दैनिक गाड़ी रिकॉर्ड, **ओबाद बनाम हैदराबाद तुलना डैशबोर्ड**, और **मासिक गाड़ी रिपोर्ट** (बड़ा व वील माल में कितना वजन कटा)।
8. **रिपोर्ट एवं पीडीएफ सिस्टम + सेटिंग व बैकअप**:
   - सभी 13 प्रकार की हिंदी पीडीएफ रिपोर्ट, फ़ोन में सहेजें, व्हाट्सऐप पर भेजें, अन्य ऐप से शेयर करें और प्रिंट करें।
   - संपूर्ण JSON बैकअप और संरचना-सत्यापित (Validated) रीस्टोर।

---

## 3. फ़ायरबेस (Firebase) कनेक्शन और सुरक्षा सेटअप निर्देश

यह एप्लीकेशन सीधे आपके फ़ायरबेस रीयलटाइम डेटाबेस से जुड़ने के लिए कॉन्फ़िगर किया गया है:
`https://haweli123-default-rtdb.firebaseio.com/`

### चरण 1: `google-services.json` जोड़ना
1. [Firebase Console](https://console.firebase.google.com/) खोलें और अपना प्रोजेक्ट चुनें।
2. **Project Settings → Your Apps → Add Android App** पर क्लिक करें।
3. पैकेज का नाम `com.haweli` दर्ज करें और `google-services.json` फ़ाइल डाउनलोड करें।
4. इस `google-services.json` फ़ाइल को प्रोजेक्ट के `HAWELI/app/google-services.json` पथ पर रखें।

### चरण 2: Firebase Authentication सक्षम करना
1. Firebase Console में **Build → Authentication → Sign-in method** पर जाएं।
2. **Email/Password** प्रदाता (Provider) को **Enable** करें (एडमिन लॉगिन के लिए)।
3. **Anonymous** प्रदाता को **Enable** करें (व्यूअर मोड के सुरक्षित रीड-ओनली एक्सेस के लिए)।

### चरण 3: Firebase Security Rules और Cloud Functions डिप्लॉय करना
1. `firebase/database.rules.json` में दिए गए नियमों को **Realtime Database → Rules** टैब में पेस्ट करके **Publish** करें।
2. टर्मिनल में `functions/` फ़ोल्डर में जाकर Cloud Functions डिप्लॉय करें:
   ```bash
   cd functions
   npm install
   export HAWELI_INITIAL_PASSWORD="Haweli"
   firebase deploy --only functions
   ```
3. प्रथम बार एडमिन जब यूज़रनेम `Haweli` और प्रारंभिक पासवर्ड `Haweli` से लॉगिन करेगा, तो `provisionInitialAdmin` और `verifyAdminRole` क्लाउड फ़ंक्शन सुरक्षित कस्टम क्लेम (`admin: true, mustChangePassword: true`) सेट करेंगे और एडमिन को तुरंत नया गुप्त पासवर्ड सेट करने के लिए बाध्य करेंगे।

---

## 4. एंड्रॉइड स्टूडियो और GitHub Actions से APK बनाने के निर्देश

### विधि A: GitHub Actions द्वारा स्वचालित APK निर्माण (Automatic APK Build)
1. इस पूरे `HAWELI` प्रोजेक्ट को अपने GitHub रिपॉजिटरी के `main` या `master` ब्रांच में पुश करें।
2. पुश होते ही `.github/workflows/android-build.yml` वर्कफ़्लो अपने आप चलेगा:
   - JDK 17 और Android SDK सेटअप करेगा।
   - सभी वित्तीय गणना यूनिट टेस्ट (`./gradlew testDebugUnitTest`) चलाएगा।
   - इंस्टॉल करने योग्य `app-debug.apk` (`./gradlew assembleDebug`) बनाएगा।
3. APK डाउनलोड करने के लिए जाएं:
   **GitHub Repository → Actions → HAWELI Android APK Build (Successful Workflow) → Artifacts → `app-debug`**।

### विधि B: Android Studio या कमांड लाइन से APK बनाना
1. प्रोजेक्ट को **Android Studio (Iguana / Jellyfish या नया)** में खोलें।
2. डीबग APK बनाने के लिए चलाएं:
   ```bash
   ./gradlew assembleDebug
   ```
   तैयार APK यहाँ मिलेगी: `app/build/outputs/apk/debug/app-debug.apk`
3. **हस्ताक्षरित रिलीज़ APK (Signed Release APK)** बनाने के लिए:
   - Android Studio में **Build → Generate Signed App Bundle / APK → APK** चुनें।
   - अपना Keystore चुनें या नया बनाएं (`keytool -genkey -v -keystore haweli-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias haweli`)।
   - `release` बिल्ड वेरिएंट चुनें और **Create** पर क्लिक करें।

---

## 5. दूसरे फ़ोन पर APK इंस्टॉल करने और दो फ़ोन पर टेस्ट करने के निर्देश

1. **फ़ोन 1 (एडमिन फ़ोन)**:
   - `app-debug.apk` इंस्टॉल करें और खोलें।
   - **सेटिंग → 1. एडमिन लॉगिन** में जाएं।
   - यूज़रनेम `Haweli` और प्रारंभिक पासवर्ड दर्ज करें, फिर प्रथम लॉगिन संवाद में अपना नया पासवर्ड सेट करें।
   - अब फ़ोन 1 पर शहर, पार्टी, दैनिक हिसाब, भुगतान और गाड़ी रिकॉर्ड जोड़ने, बदलने और हटाने के सभी अधिकार सक्रिय हैं।
2. **फ़ोन 2 (व्यूअर फ़ोन)**:
   - फ़ोन 1 से **सेटिंग → 8. HAWELI एप्लीकेशन (APK) दूसरे फ़ोन पर भेजें** दबाकर व्हाट्सऐप या ब्लूटूथ से APK फ़ोन 2 पर भेजें और इंस्टॉल करें।
   - फ़ोन 2 में ऐप खोलते ही यह बिना किसी पासवर्ड के सीधे **व्यूअर मोड** में खुलेगा।
   - जब एडमिन फ़ोन 1 पर कोई भी एंट्री या भुगतान जोड़ेगा या बदलेगा, तो फ़ोन 2 पर बिना रिफ्रेश किए रीयलटाइम में तुरंत अपडेट दिखाई देगा।
   - व्यूअर फ़ोन 2 पर सभी खाते देख सकता है, खोज/फ़िल्टर कर सकता है और हिंदी पीडीएफ रिपोर्ट डाउनलोड या व्हाट्सऐप पर शेयर कर सकता है, लेकिन कोई भी डेटा बदल या हटा नहीं सकता।
